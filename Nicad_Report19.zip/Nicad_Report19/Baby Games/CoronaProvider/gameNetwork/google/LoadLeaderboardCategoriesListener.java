package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardBuffer;
import com.google.android.gms.games.leaderboard.OnLeaderboardMetadataLoadedListener;
import com.naef.jnlua.LuaState;

public class LoadLeaderboardCategoriesListener extends Listener implements OnLeaderboardMetadataLoadedListener {
  public LoadLeaderboardCategoriesListener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
  }
  
  public void onLeaderboardMetadataLoaded(int paramInt, final LeaderboardBuffer buffer) {
    if (this.fListener < 0)
      return; 
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          try {
            LuaState luaState = param1CoronaRuntime.getLuaState();
            CoronaLua.newEvent(luaState, "loadLeaderboardCategories");
            luaState.pushString("loadLeaderboardCategories");
            luaState.setField(-2, "type");
            luaState.newTable(buffer.getCount() + 1, 0);
            for (int i = 0; i < buffer.getCount(); i++) {
              Listener.pushLeaderboardToLua(luaState, (Leaderboard)buffer.get(i));
              luaState.rawSet(-2, i + 1);
            } 
            luaState.setField(-2, "data");
            CoronaLua.dispatchEvent(luaState, LoadLeaderboardCategoriesListener.this.fListener, 0);
            CoronaLua.deleteRef(luaState, LoadLeaderboardCategoriesListener.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\LoadLeaderboardCategoriesListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */