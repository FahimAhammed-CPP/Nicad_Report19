package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.naef.jnlua.LuaState;

public class SignInListener extends Listener implements GameHelper.GameHelperListener {
  int count = 0;
  
  public SignInListener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
  }
  
  private void callBackListener(final boolean isError) {
    if (this.fListener < 0 || this.count > 0)
      return; 
    this.count++;
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          try {
            LuaState luaState = param1CoronaRuntime.getLuaState();
            CoronaLua.newEvent(luaState, "login");
            luaState.pushString("login");
            luaState.setField(-2, "type");
            if (isError) {
              luaState.pushBoolean(isError);
              luaState.setField(-2, "isError");
            } 
            CoronaLua.dispatchEvent(luaState, SignInListener.this.fListener, 0);
            CoronaLua.deleteRef(luaState, SignInListener.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
  
  public void onSignInFailed() {
    callBackListener(true);
  }
  
  public void onSignInSucceeded() {
    callBackListener(false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\SignInListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */