package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.OnPlayersLoadedListener;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.naef.jnlua.LuaState;
import java.util.HashSet;
import java.util.Iterator;

public class PlayerLoaderManager {
  protected CoronaRuntimeTaskDispatcher fDispatcher;
  
  protected String fEventName;
  
  protected GamesClient fGamesClient;
  
  protected int fListener;
  
  protected boolean fLocalPlayer;
  
  protected HashSet<String> fNameSet;
  
  protected HashSet<Player> fPlayerSet = new HashSet<Player>();
  
  public PlayerLoaderManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient, String paramString) {
    this.fDispatcher = paramCoronaRuntimeTaskDispatcher;
    this.fListener = paramInt;
    this.fGamesClient = paramGamesClient;
    this.fEventName = paramString;
  }
  
  public void loadPlayers(HashSet<String> paramHashSet, boolean paramBoolean) {
    this.fNameSet = paramHashSet;
    paramHashSet = new HashSet<String>();
    Iterator<String> iterator2 = this.fNameSet.iterator();
    while (iterator2.hasNext())
      paramHashSet.add(new String(iterator2.next())); 
    this.fLocalPlayer = paramBoolean;
    Iterator<String> iterator1 = paramHashSet.iterator();
    while (iterator1.hasNext())
      this.fGamesClient.loadPlayer(new LoadPlayerListener(), iterator1.next()); 
  }
  
  public class LoadPlayerListener implements OnPlayersLoadedListener {
    private void callback() {
      if (PlayerLoaderManager.this.fListener < 0)
        return; 
      CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
          public void executeUsing(CoronaRuntime param2CoronaRuntime) {
            Iterator<Player> iterator = finalPlayerSet.iterator();
            LuaState luaState = param2CoronaRuntime.getLuaState();
            CoronaLua.newEvent(luaState, PlayerLoaderManager.this.fEventName);
            luaState.pushString(PlayerLoaderManager.this.fEventName);
            luaState.setField(-2, "type");
            luaState.newTable(finalPlayerSet.size(), 0);
            int i = 1;
            while (iterator.hasNext()) {
              Player player = iterator.next();
              if (!PlayerLoaderManager.this.fLocalPlayer && finalPlayerSet.size() > 1)
                luaState.newTable(0, 2); 
              luaState.pushString(player.getPlayerId());
              luaState.setField(-2, "playerID");
              luaState.pushString(player.getDisplayName());
              luaState.setField(-2, "alias");
              if (!PlayerLoaderManager.this.fLocalPlayer && finalPlayerSet.size() > 1) {
                luaState.rawSet(-2, i);
                i++;
              } 
            } 
            luaState.setField(-2, "data");
            try {
              CoronaLua.dispatchEvent(luaState, PlayerLoaderManager.this.fListener, 0);
              CoronaLua.deleteRef(luaState, PlayerLoaderManager.this.fListener);
              return;
            } catch (Exception exception) {
              exception.printStackTrace();
              return;
            } 
          }
        };
      PlayerLoaderManager.this.fDispatcher.send(coronaRuntimeTask);
    }
    
    public void onPlayersLoaded(int param1Int, PlayerBuffer param1PlayerBuffer) {
      for (param1Int = 0; param1Int < param1PlayerBuffer.getCount(); param1Int++) {
        PlayerLoaderManager.this.fPlayerSet.add(param1PlayerBuffer.get(param1Int));
        PlayerLoaderManager.this.fNameSet.remove(param1PlayerBuffer.get(param1Int).getPlayerId());
      } 
      if (PlayerLoaderManager.this.fNameSet.size() < 1)
        callback(); 
    }
  }
  
  class null implements CoronaRuntimeTask {
    public void executeUsing(CoronaRuntime param1CoronaRuntime) {
      Iterator<Player> iterator = finalPlayerSet.iterator();
      LuaState luaState = param1CoronaRuntime.getLuaState();
      CoronaLua.newEvent(luaState, PlayerLoaderManager.this.fEventName);
      luaState.pushString(PlayerLoaderManager.this.fEventName);
      luaState.setField(-2, "type");
      luaState.newTable(finalPlayerSet.size(), 0);
      int i = 1;
      while (iterator.hasNext()) {
        Player player = iterator.next();
        if (!PlayerLoaderManager.this.fLocalPlayer && finalPlayerSet.size() > 1)
          luaState.newTable(0, 2); 
        luaState.pushString(player.getPlayerId());
        luaState.setField(-2, "playerID");
        luaState.pushString(player.getDisplayName());
        luaState.setField(-2, "alias");
        if (!PlayerLoaderManager.this.fLocalPlayer && finalPlayerSet.size() > 1) {
          luaState.rawSet(-2, i);
          i++;
        } 
      } 
      luaState.setField(-2, "data");
      try {
        CoronaLua.dispatchEvent(luaState, PlayerLoaderManager.this.fListener, 0);
        CoronaLua.deleteRef(luaState, PlayerLoaderManager.this.fListener);
        return;
      } catch (Exception exception) {
        exception.printStackTrace();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\PlayerLoaderManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */