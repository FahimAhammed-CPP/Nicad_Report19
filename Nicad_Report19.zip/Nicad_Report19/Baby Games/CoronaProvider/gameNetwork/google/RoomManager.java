package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.naef.jnlua.LuaState;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

public class RoomManager implements RoomUpdateListener, RoomStatusUpdateListener {
  public static final String ROOM_ID = "roomID";
  
  static CoronaRuntimeTaskDispatcher fDispatcher;
  
  static GamesClient fGamesClient;
  
  static int fRoomListener;
  
  static RoomManager fRoomManager;
  
  static HashMap<String, Room> fRooms = new HashMap<String, Room>();
  
  private RoomManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient) {
    fGamesClient = paramGamesClient;
    fRoomListener = paramInt;
  }
  
  public static Room getRoom(String paramString) {
    return fRooms.get(paramString);
  }
  
  public static RoomManager getRoomManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient) {
    if (fRoomManager == null)
      fRoomManager = new RoomManager(paramCoronaRuntimeTaskDispatcher, paramInt, paramGamesClient); 
    fDispatcher = paramCoronaRuntimeTaskDispatcher;
    setRoomListener(paramInt);
    return fRoomManager;
  }
  
  private void pushToLua(final String type, final Room room, final List<String> participantIds, final boolean isError) {
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, type);
          luaState.pushString(type);
          luaState.setField(-2, "type");
          luaState.newTable();
          int i = 1;
          if (participantIds != null) {
            ListIterator<String> listIterator = participantIds.listIterator();
            while (listIterator.hasNext()) {
              String str = listIterator.next();
              if (room != null && str != room.getParticipantId(RoomManager.fGamesClient.getCurrentPlayerId())) {
                luaState.pushString(str);
                luaState.rawSet(-2, i);
                i++;
              } 
            } 
          } 
          if (room != null) {
            luaState.pushString(room.getRoomId());
            luaState.setField(-2, "roomID");
          } 
          luaState.pushBoolean(isError);
          luaState.setField(-2, "isError");
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, RoomManager.fRoomListener, 0);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    fDispatcher.send(coronaRuntimeTask);
  }
  
  public static void setRoomListener(int paramInt) {
    fRoomListener = paramInt;
  }
  
  public void onConnectedToRoom(Room paramRoom) {}
  
  public void onDisconnectedFromRoom(Room paramRoom) {}
  
  public void onJoinedRoom(int paramInt, Room paramRoom) {
    boolean bool = false;
    if (paramRoom == null) {
      bool = true;
    } else {
      fRooms.put(paramRoom.getRoomId(), paramRoom);
    } 
    pushToLua("joinRoom", paramRoom, null, bool);
  }
  
  public void onLeftRoom(int paramInt, final String finalRoomId) {
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "leaveRoom");
          luaState.pushString("leaveRoom");
          luaState.setField(-2, "type");
          luaState.newTable();
          luaState.pushString(finalRoomId);
          luaState.setField(-2, "roomID");
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, RoomManager.fRoomListener, 0);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    fDispatcher.send(coronaRuntimeTask);
  }
  
  public void onP2PConnected(String paramString) {}
  
  public void onP2PDisconnected(String paramString) {}
  
  public void onPeerDeclined(Room paramRoom, List<String> paramList) {
    pushToLua("peerDeclinedInvitation", paramRoom, paramList, false);
  }
  
  public void onPeerInvitedToRoom(Room paramRoom, List<String> paramList) {}
  
  public void onPeerJoined(Room paramRoom, List<String> paramList) {
    pushToLua("peerAcceptedInvitation", paramRoom, paramList, false);
  }
  
  public void onPeerLeft(Room paramRoom, List<String> paramList) {
    pushToLua("peerLeftRoom", paramRoom, paramList, false);
  }
  
  public void onPeersConnected(Room paramRoom, List<String> paramList) {}
  
  public void onPeersDisconnected(Room paramRoom, List<String> paramList) {
    pushToLua("peerDisconnectedFromRoom", paramRoom, paramList, false);
  }
  
  public void onRoomAutoMatching(Room paramRoom) {}
  
  public void onRoomConnected(int paramInt, Room paramRoom) {
    pushToLua("connectedRoom", paramRoom, paramRoom.getParticipantIds(), false);
  }
  
  public void onRoomConnecting(Room paramRoom) {}
  
  public void onRoomCreated(int paramInt, Room paramRoom) {
    boolean bool = false;
    if (paramRoom == null) {
      bool = true;
    } else {
      fRooms.put(paramRoom.getRoomId(), paramRoom);
    } 
    pushToLua("createRoom", paramRoom, null, bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\RoomManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */