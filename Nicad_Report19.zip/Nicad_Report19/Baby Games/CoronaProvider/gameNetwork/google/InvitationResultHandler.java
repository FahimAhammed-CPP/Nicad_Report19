package CoronaProvider.gameNetwork.google;

import android.content.Intent;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.multiplayer.Invitation;
import com.naef.jnlua.LuaState;

public class InvitationResultHandler extends Listener implements CoronaActivity.OnActivityResultHandler {
  private GameHelper fGameHelper;
  
  public InvitationResultHandler(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GameHelper paramGameHelper) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
    this.fGameHelper = paramGameHelper;
  }
  
  private void pushInvitationsToLua(final String invitationId, final boolean isError, final String phase) {
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "invitations");
          luaState.pushString("invitations");
          luaState.setField(-2, "type");
          luaState.newTable();
          luaState.pushString(invitationId);
          luaState.setField(-2, "roomID");
          luaState.pushString(phase);
          luaState.setField(-2, "phase");
          luaState.pushBoolean(isError);
          luaState.setField(-2, "isError");
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, InvitationResultHandler.this.fListener, 0);
            CoronaLua.deleteRef(luaState, InvitationResultHandler.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
  
  public void onHandleActivityResult(CoronaActivity paramCoronaActivity, int paramInt1, int paramInt2, Intent paramIntent) {
    paramCoronaActivity.unregisterActivityResultHandler(this);
    paramCoronaActivity.getRuntimeTaskDispatcher();
    if (-1 == paramInt2) {
      pushInvitationsToLua(((Invitation)paramIntent.getExtras().getParcelable("invitation")).getInvitationId(), false, "selected");
      return;
    } 
    if (10001 == paramInt2) {
      if (this.fGameHelper != null && this.fGameHelper.getGamesClient() != null)
        this.fGameHelper.signOut(); 
      pushInvitationsToLua("", true, "logout");
      return;
    } 
    pushInvitationsToLua("", true, "cancelled");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\InvitationResultHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */