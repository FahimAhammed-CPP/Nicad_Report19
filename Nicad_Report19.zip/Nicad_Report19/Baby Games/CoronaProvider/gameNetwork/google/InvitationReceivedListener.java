package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.naef.jnlua.LuaState;

public class InvitationReceivedListener extends Listener implements OnInvitationReceivedListener {
  public InvitationReceivedListener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
  }
  
  public void onInvitationReceived(final Invitation finalInvitation) {
    if (this.fListener < 0)
      return; 
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "invitationReceived");
          luaState.pushString("invitationReceived");
          luaState.setField(-2, "type");
          Listener.pushInvitationToLua(luaState, finalInvitation);
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, InvitationReceivedListener.this.fListener, 0);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
  
  public void onInvitationRemoved(String paramString) {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\InvitationReceivedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */