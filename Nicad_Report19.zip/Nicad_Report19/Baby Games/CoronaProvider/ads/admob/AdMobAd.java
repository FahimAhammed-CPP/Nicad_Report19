package CoronaProvider.ads.admob;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsoluteLayout;
import android.widget.RelativeLayout;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaEnvironment;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class AdMobAd {
  public static final String BANNER = "banner";
  
  public static final String INTERSTITIAL = "interstitial";
  
  public static final String LOADED = "loaded";
  
  public static final String REFRESHED = "refreshed";
  
  public static final String SHOWN = "shown";
  
  private AbsoluteLayout fAbsoluteLayout;
  
  private AdView fAdView;
  
  private String fAppId;
  
  private Handler fHandler;
  
  private InterstitialAd fInterstitialAd;
  
  volatile boolean fInterstitialIsLoaded;
  
  private ViewGroup.LayoutParams fLayoutParams;
  
  private RelativeLayout fRelativeLayout;
  
  private ViewGroup fViewGroup;
  
  AdMobAd(String paramString) {
    this.fAppId = paramString;
    this.fHandler = new Handler(Looper.getMainLooper());
    this.fInterstitialIsLoaded = false;
  }
  
  public static String getDeviceId() {
    String str2 = "";
    String str1 = Settings.Secure.getString(CoronaEnvironment.getApplicationContext().getContentResolver(), "android_id");
    try {
      byte[] arrayOfByte = MessageDigest.getInstance("MD5").digest(str1.getBytes());
      StringBuffer stringBuffer = new StringBuffer();
      for (int i = 0; i < arrayOfByte.length; i++) {
        for (str1 = Integer.toHexString(arrayOfByte[i] & 0xFF); str1.length() < 2; str1 = "0" + str1);
        stringBuffer.append(str1);
      } 
      str1 = stringBuffer.toString();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      noSuchAlgorithmException.printStackTrace();
      str1 = str2;
    } 
    return str1.toUpperCase();
  }
  
  public void destroy() {
    this.fHandler.post(new Runnable() {
          public void run() {
            if (AdMobAd.this.fAdView != null)
              AdMobAd.this.fAdView.destroy(); 
          }
        });
  }
  
  protected AbsoluteLayout getParent() {
    if (this.fAbsoluteLayout == null) {
      this.fAbsoluteLayout = new AbsoluteLayout((Context)CoronaEnvironment.getCoronaActivity());
      CoronaEnvironment.getCoronaActivity().getOverlayView().addView((View)this.fAbsoluteLayout);
    } 
    return this.fAbsoluteLayout;
  }
  
  protected int getParentHeight() {
    return CoronaEnvironment.getCoronaActivity().getOverlayView().getHeight();
  }
  
  protected RelativeLayout getRelativeParent() {
    if (this.fRelativeLayout == null) {
      this.fRelativeLayout = new RelativeLayout((Context)CoronaEnvironment.getCoronaActivity());
      CoronaEnvironment.getCoronaActivity().getOverlayView().addView((View)this.fRelativeLayout);
    } 
    return this.fRelativeLayout;
  }
  
  void hide() {
    if (CoronaEnvironment.getCoronaActivity() == null)
      return; 
    CoronaEnvironment.getCoronaActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (AdMobAd.this.getParent() != null)
              AdMobAd.this.getParent().removeView((View)AdMobAd.this.fAdView); 
            if (AdMobAd.this.getRelativeParent() != null)
              AdMobAd.this.getRelativeParent().removeView((View)AdMobAd.this.fAdView); 
            if (AdMobAd.this.fAdView != null) {
              AdMobAd.this.fAdView.destroy();
              AdMobAd.access$002(AdMobAd.this, null);
            } 
          }
        });
  }
  
  boolean isLoaded(String paramString) {
    return paramString.equals("interstitial") ? this.fInterstitialIsLoaded : false;
  }
  
  void load(String paramString, boolean paramBoolean) {
    if (paramString.equals("interstitial"))
      loadInterstital(paramBoolean); 
  }
  
  void loadInterstital(final boolean testMode) {
    if (CoronaEnvironment.getCoronaActivity() == null) {
      LuaLoader.dispatchEvent(true, "No corona activity", null, null);
      return;
    } 
    final String copyAppId = this.fAppId;
    if (str == null || str.length() <= 0) {
      LuaLoader.dispatchEvent(true, "No app id", null, null);
      return;
    } 
    CoronaEnvironment.getCoronaActivity().runOnUiThread(new Runnable() {
          public void run() {
            AdMobAd.access$302(AdMobAd.this, new InterstitialAd((Context)CoronaEnvironment.getCoronaActivity()));
            AdMobAd.this.fInterstitialAd.setAdUnitId(copyAppId);
            AdMobAd.this.fInterstitialAd.setAdListener(new AdMobAd.AdmobInterstitialListener(false));
            AdRequest.Builder builder = new AdRequest.Builder();
            builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
            if (testMode)
              builder.addTestDevice(AdMobAd.getDeviceId()); 
            AdMobAd.this.fInterstitialAd.loadAd(builder.build());
          }
        });
  }
  
  public void pause() {
    this.fHandler.post(new Runnable() {
          public void run() {
            if (AdMobAd.this.fAdView != null)
              AdMobAd.this.fAdView.pause(); 
          }
        });
  }
  
  public void resume() {
    this.fHandler.post(new Runnable() {
          public void run() {
            if (AdMobAd.this.fAdView != null)
              AdMobAd.this.fAdView.resume(); 
          }
        });
  }
  
  public void setAppId(String paramString) {
    this.fAppId = paramString;
  }
  
  double show(final int xCoordinate, final int yCoordinate, final boolean testMode) {
    hide();
    if (CoronaEnvironment.getCoronaActivity() == null) {
      LuaLoader.dispatchEvent(true, "No corona activity", null, null);
      return 0.0D;
    } 
    if (this.fAppId == null || this.fAppId.length() <= 0) {
      LuaLoader.dispatchEvent(true, "No app id", null, null);
      return 0.0D;
    } 
    final String copyAppId = this.fAppId;
    final CoronaActivity activity = CoronaEnvironment.getCoronaActivity();
    final int bannerWidth = 0;
    int j = coronaActivity.getContentWidthInPixels();
    int k = coronaActivity.getHorizontalMarginInPixels();
    if (xCoordinate >= k && xCoordinate < j + k) {
      i = j - xCoordinate - k;
      float f1 = (coronaActivity.getResources().getDisplayMetrics()).density;
      final AdSize adSize = new AdSize((int)(i / f1), -2);
      CoronaEnvironment.getCoronaActivity().runOnUiThread(new Runnable() {
            public void run() {
              AdMobAd.access$002(AdMobAd.this, new AdView((Context)activity));
              AdMobAd.this.fAdView.setAdSize(adSize);
              AdMobAd.this.fAdView.setAdUnitId(copyAppId);
              AdMobAd.this.fAdView.setAdListener(new AdMobAd.AdmobBannerListener());
              if (yCoordinate >= AdMobAd.this.getParentHeight()) {
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(bannerWidth, -2);
                layoutParams.addRule(12);
                AdMobAd.access$102(AdMobAd.this, (ViewGroup.LayoutParams)layoutParams);
                AdMobAd.access$202(AdMobAd.this, (ViewGroup)AdMobAd.this.getRelativeParent());
              } else {
                AbsoluteLayout.LayoutParams layoutParams = new AbsoluteLayout.LayoutParams(bannerWidth, -2, xCoordinate, yCoordinate);
                AdMobAd.access$102(AdMobAd.this, (ViewGroup.LayoutParams)layoutParams);
                AdMobAd.access$202(AdMobAd.this, (ViewGroup)AdMobAd.this.getParent());
              } 
              AdRequest.Builder builder = new AdRequest.Builder();
              builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
              if (testMode)
                builder.addTestDevice(AdMobAd.getDeviceId()); 
              AdMobAd.this.fAdView.loadAd(builder.build());
            }
          });
      return adSize1.getHeightInPixels((Context)CoronaEnvironment.getCoronaActivity()) / coronaActivity.getContentHeightInPixels();
    } 
    if (xCoordinate < k)
      i = j + (k - xCoordinate) * 2; 
    float f = (coronaActivity.getResources().getDisplayMetrics()).density;
    final AdSize adSize = new AdSize((int)(i / f), -2);
    CoronaEnvironment.getCoronaActivity().runOnUiThread(new Runnable() {
          public void run() {
            AdMobAd.access$002(AdMobAd.this, new AdView((Context)activity));
            AdMobAd.this.fAdView.setAdSize(adSize);
            AdMobAd.this.fAdView.setAdUnitId(copyAppId);
            AdMobAd.this.fAdView.setAdListener(new AdMobAd.AdmobBannerListener());
            if (yCoordinate >= AdMobAd.this.getParentHeight()) {
              RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(bannerWidth, -2);
              layoutParams.addRule(12);
              AdMobAd.access$102(AdMobAd.this, (ViewGroup.LayoutParams)layoutParams);
              AdMobAd.access$202(AdMobAd.this, (ViewGroup)AdMobAd.this.getRelativeParent());
            } else {
              AbsoluteLayout.LayoutParams layoutParams = new AbsoluteLayout.LayoutParams(bannerWidth, -2, xCoordinate, yCoordinate);
              AdMobAd.access$102(AdMobAd.this, (ViewGroup.LayoutParams)layoutParams);
              AdMobAd.access$202(AdMobAd.this, (ViewGroup)AdMobAd.this.getParent());
            } 
            AdRequest.Builder builder = new AdRequest.Builder();
            builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
            if (testMode)
              builder.addTestDevice(AdMobAd.getDeviceId()); 
            AdMobAd.this.fAdView.loadAd(builder.build());
          }
        });
    return adSize.getHeightInPixels((Context)CoronaEnvironment.getCoronaActivity()) / coronaActivity.getContentHeightInPixels();
  }
  
  void showInterstitialAd(final boolean testMode) {
    if (CoronaEnvironment.getCoronaActivity() == null) {
      LuaLoader.dispatchEvent(true, "No corona activity", null, null);
      return;
    } 
    final String copyAppId = this.fAppId;
    if (str == null || str.length() <= 0) {
      LuaLoader.dispatchEvent(true, "No app id", null, null);
      return;
    } 
    CoronaEnvironment.getCoronaActivity().runOnUiThread(new Runnable() {
          public void run() {
            if (AdMobAd.this.fInterstitialAd != null && AdMobAd.this.fInterstitialAd.isLoaded()) {
              AdMobAd.this.fInterstitialAd.show();
              return;
            } 
            AdMobAd.access$302(AdMobAd.this, new InterstitialAd((Context)CoronaEnvironment.getCoronaActivity()));
            AdMobAd.this.fInterstitialAd.setAdUnitId(copyAppId);
            AdMobAd.this.fInterstitialAd.setAdListener(new AdMobAd.AdmobInterstitialListener(true));
            AdRequest.Builder builder = new AdRequest.Builder();
            builder.addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
            if (testMode)
              builder.addTestDevice(AdMobAd.getDeviceId()); 
            AdMobAd.this.fInterstitialAd.loadAd(builder.build());
          }
        });
  }
  
  private class AdmobBannerListener extends AdmobListener {
    private boolean fFirstTime = true;
    
    public void onAdFailedToLoad(int param1Int) {
      super.onAdFailedToLoad(param1Int);
      LuaLoader.dispatchEvent(true, translateErrorCode(param1Int), "banner", "loaded");
    }
    
    public void onAdLoaded() {
      if (this.fFirstTime) {
        AdMobAd.this.fViewGroup.addView((View)AdMobAd.this.fAdView, AdMobAd.this.fLayoutParams);
        this.fFirstTime = false;
        LuaLoader.dispatchEvent(false, "", "banner", "shown");
      } else {
        LuaLoader.dispatchEvent(false, "", "banner", "refreshed");
      } 
      super.onAdLoaded();
    }
  }
  
  private class AdmobInterstitialListener extends AdmobListener {
    boolean mShouldShow;
    
    public AdmobInterstitialListener(boolean param1Boolean) {
      this.mShouldShow = param1Boolean;
      AdMobAd.this.fInterstitialIsLoaded = false;
    }
    
    public void onAdClosed() {
      super.onAdClosed();
      LuaLoader.dispatchEvent(false, null, "interstitial", "shown");
    }
    
    public void onAdFailedToLoad(int param1Int) {
      super.onAdFailedToLoad(param1Int);
      LuaLoader.dispatchEvent(true, translateErrorCode(param1Int), "interstitial", "loaded");
      AdMobAd.this.fInterstitialIsLoaded = false;
    }
    
    public void onAdLoaded() {
      AdMobAd.this.fInterstitialIsLoaded = true;
      if (this.mShouldShow) {
        AdMobAd.this.fInterstitialAd.show();
      } else {
        LuaLoader.dispatchEvent(false, "", "interstitial", "loaded");
      } 
      super.onAdLoaded();
    }
  }
  
  private abstract class AdmobListener extends AdListener {
    private AdmobListener() {}
    
    protected String translateErrorCode(int param1Int) {
      switch (param1Int) {
        default:
          return "";
        case 0:
          return "Something happened internally in the AdmobSDK; for instance, an invalid response was received from the ad server.";
        case 1:
          return "The ad request was invalid; for instance, the ad unit ID was incorrect.";
        case 2:
          return "The ad request was unsuccessful due to network connectivity.";
        case 3:
          break;
      } 
      return "The ad request was successful, but no ad was returned due to lack of ad inventory.";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\ads\admob\AdMobAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */