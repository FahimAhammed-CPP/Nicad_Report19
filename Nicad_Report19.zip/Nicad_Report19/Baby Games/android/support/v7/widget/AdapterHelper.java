package android.support.v7.widget;

import android.support.v4.util.Pools;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class AdapterHelper implements OpReorderer.Callback {
  private static final boolean DEBUG = false;
  
  static final int POSITION_TYPE_INVISIBLE = 0;
  
  static final int POSITION_TYPE_NEW_OR_LAID_OUT = 1;
  
  private static final String TAG = "AHT";
  
  final Callback mCallback;
  
  final boolean mDisableRecycler;
  
  private int mExistingUpdateTypes = 0;
  
  Runnable mOnItemProcessedCallback;
  
  final OpReorderer mOpReorderer;
  
  final ArrayList<UpdateOp> mPendingUpdates = new ArrayList<UpdateOp>();
  
  final ArrayList<UpdateOp> mPostponedList = new ArrayList<UpdateOp>();
  
  private Pools.Pool<UpdateOp> mUpdateOpPool = (Pools.Pool<UpdateOp>)new Pools.SimplePool(30);
  
  AdapterHelper(Callback paramCallback) {
    this(paramCallback, false);
  }
  
  AdapterHelper(Callback paramCallback, boolean paramBoolean) {
    this.mCallback = paramCallback;
    this.mDisableRecycler = paramBoolean;
    this.mOpReorderer = new OpReorderer(this);
  }
  
  private void applyAdd(UpdateOp paramUpdateOp) {
    postponeAndUpdateViewHolders(paramUpdateOp);
  }
  
  private void applyMove(UpdateOp paramUpdateOp) {
    postponeAndUpdateViewHolders(paramUpdateOp);
  }
  
  private void applyRemove(UpdateOp paramUpdateOp) {
    int m = paramUpdateOp.positionStart;
    int k = 0;
    int j = paramUpdateOp.positionStart + paramUpdateOp.itemCount;
    byte b = -1;
    int i = paramUpdateOp.positionStart;
    while (i < j) {
      int n = 0;
      byte b1 = 0;
      if (this.mCallback.findViewHolder(i) != null || canFindInPreLayout(i)) {
        if (b == 0) {
          dispatchAndUpdateViewHolders(obtainUpdateOp(2, m, k, null));
          b1 = 1;
        } 
        b = 1;
        n = b1;
        b1 = b;
      } else {
        if (b == 1) {
          postponeAndUpdateViewHolders(obtainUpdateOp(2, m, k, null));
          n = 1;
        } 
        b1 = 0;
      } 
      if (n != 0) {
        i -= k;
        j -= k;
        n = 1;
      } else {
        n = k + 1;
      } 
      i++;
      k = n;
      b = b1;
    } 
    UpdateOp updateOp = paramUpdateOp;
    if (k != paramUpdateOp.itemCount) {
      recycleUpdateOp(paramUpdateOp);
      updateOp = obtainUpdateOp(2, m, k, null);
    } 
    if (b == 0) {
      dispatchAndUpdateViewHolders(updateOp);
      return;
    } 
    postponeAndUpdateViewHolders(updateOp);
  }
  
  private void applyUpdate(UpdateOp paramUpdateOp) {
    int k = paramUpdateOp.positionStart;
    int j = 0;
    int n = paramUpdateOp.positionStart;
    int i1 = paramUpdateOp.itemCount;
    int m = -1;
    int i = paramUpdateOp.positionStart;
    while (i < n + i1) {
      int i2;
      int i3;
      if (this.mCallback.findViewHolder(i) != null || canFindInPreLayout(i)) {
        i3 = j;
        int i4 = k;
        if (m == 0) {
          dispatchAndUpdateViewHolders(obtainUpdateOp(4, k, j, paramUpdateOp.payload));
          i3 = 0;
          i4 = i;
        } 
        i2 = 1;
        k = i4;
      } else {
        i3 = j;
        i2 = k;
        if (m == 1) {
          postponeAndUpdateViewHolders(obtainUpdateOp(4, k, j, paramUpdateOp.payload));
          i3 = 0;
          i2 = i;
        } 
        j = 0;
        k = i2;
        i2 = j;
      } 
      j = i3 + 1;
      i++;
      m = i2;
    } 
    Object object = paramUpdateOp;
    if (j != paramUpdateOp.itemCount) {
      object = paramUpdateOp.payload;
      recycleUpdateOp(paramUpdateOp);
      object = obtainUpdateOp(4, k, j, object);
    } 
    if (m == 0) {
      dispatchAndUpdateViewHolders((UpdateOp)object);
      return;
    } 
    postponeAndUpdateViewHolders((UpdateOp)object);
  }
  
  private boolean canFindInPreLayout(int paramInt) {
    int j = this.mPostponedList.size();
    for (int i = 0; i < j; i++) {
      UpdateOp updateOp = this.mPostponedList.get(i);
      if (updateOp.cmd == 8) {
        if (findPositionOffset(updateOp.itemCount, i + 1) == paramInt)
          continue; 
      } else if (updateOp.cmd == 1) {
        int m = updateOp.positionStart;
        int n = updateOp.itemCount;
        int k = updateOp.positionStart;
        while (k < m + n) {
          if (findPositionOffset(k, i + 1) != paramInt) {
            k++;
            continue;
          } 
          return true;
        } 
      } 
    } 
    return false;
  }
  
  private void dispatchAndUpdateViewHolders(UpdateOp paramUpdateOp) {
    // Byte code:
    //   0: aload_1
    //   1: getfield cmd : I
    //   4: iconst_1
    //   5: if_icmpeq -> 17
    //   8: aload_1
    //   9: getfield cmd : I
    //   12: bipush #8
    //   14: if_icmpne -> 27
    //   17: new java/lang/IllegalArgumentException
    //   20: dup
    //   21: ldc 'should not dispatch add or move for pre layout'
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: athrow
    //   27: aload_0
    //   28: aload_1
    //   29: getfield positionStart : I
    //   32: aload_1
    //   33: getfield cmd : I
    //   36: invokespecial updatePositionWithPostponed : (II)I
    //   39: istore #7
    //   41: iconst_1
    //   42: istore #6
    //   44: aload_1
    //   45: getfield positionStart : I
    //   48: istore_2
    //   49: aload_1
    //   50: getfield cmd : I
    //   53: tableswitch default -> 80, 2 -> 204, 3 -> 80, 4 -> 107
    //   80: new java/lang/IllegalArgumentException
    //   83: dup
    //   84: new java/lang/StringBuilder
    //   87: dup
    //   88: invokespecial <init> : ()V
    //   91: ldc 'op should be remove or update.'
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: aload_1
    //   97: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: invokespecial <init> : (Ljava/lang/String;)V
    //   106: athrow
    //   107: iconst_1
    //   108: istore #4
    //   110: iconst_1
    //   111: istore #5
    //   113: iload #5
    //   115: aload_1
    //   116: getfield itemCount : I
    //   119: if_icmpge -> 307
    //   122: aload_0
    //   123: aload_1
    //   124: getfield positionStart : I
    //   127: iload #4
    //   129: iload #5
    //   131: imul
    //   132: iadd
    //   133: aload_1
    //   134: getfield cmd : I
    //   137: invokespecial updatePositionWithPostponed : (II)I
    //   140: istore #8
    //   142: iconst_0
    //   143: istore #9
    //   145: iload #9
    //   147: istore_3
    //   148: aload_1
    //   149: getfield cmd : I
    //   152: tableswitch default -> 180, 2 -> 229, 3 -> 183, 4 -> 210
    //   180: iload #9
    //   182: istore_3
    //   183: iload_3
    //   184: ifeq -> 246
    //   187: iload #6
    //   189: iconst_1
    //   190: iadd
    //   191: istore_3
    //   192: iload #5
    //   194: iconst_1
    //   195: iadd
    //   196: istore #5
    //   198: iload_3
    //   199: istore #6
    //   201: goto -> 113
    //   204: iconst_0
    //   205: istore #4
    //   207: goto -> 110
    //   210: iload #8
    //   212: iload #7
    //   214: iconst_1
    //   215: iadd
    //   216: if_icmpne -> 224
    //   219: iconst_1
    //   220: istore_3
    //   221: goto -> 183
    //   224: iconst_0
    //   225: istore_3
    //   226: goto -> 221
    //   229: iload #8
    //   231: iload #7
    //   233: if_icmpne -> 241
    //   236: iconst_1
    //   237: istore_3
    //   238: goto -> 183
    //   241: iconst_0
    //   242: istore_3
    //   243: goto -> 238
    //   246: aload_0
    //   247: aload_1
    //   248: getfield cmd : I
    //   251: iload #7
    //   253: iload #6
    //   255: aload_1
    //   256: getfield payload : Ljava/lang/Object;
    //   259: invokevirtual obtainUpdateOp : (IIILjava/lang/Object;)Landroid/support/v7/widget/AdapterHelper$UpdateOp;
    //   262: astore #10
    //   264: aload_0
    //   265: aload #10
    //   267: iload_2
    //   268: invokevirtual dispatchFirstPassAndUpdateViewHolders : (Landroid/support/v7/widget/AdapterHelper$UpdateOp;I)V
    //   271: aload_0
    //   272: aload #10
    //   274: invokevirtual recycleUpdateOp : (Landroid/support/v7/widget/AdapterHelper$UpdateOp;)V
    //   277: iload_2
    //   278: istore_3
    //   279: aload_1
    //   280: getfield cmd : I
    //   283: iconst_4
    //   284: if_icmpne -> 292
    //   287: iload_2
    //   288: iload #6
    //   290: iadd
    //   291: istore_3
    //   292: iload #8
    //   294: istore #7
    //   296: iconst_1
    //   297: istore #6
    //   299: iload_3
    //   300: istore_2
    //   301: iload #6
    //   303: istore_3
    //   304: goto -> 192
    //   307: aload_1
    //   308: getfield payload : Ljava/lang/Object;
    //   311: astore #10
    //   313: aload_0
    //   314: aload_1
    //   315: invokevirtual recycleUpdateOp : (Landroid/support/v7/widget/AdapterHelper$UpdateOp;)V
    //   318: iload #6
    //   320: ifle -> 349
    //   323: aload_0
    //   324: aload_1
    //   325: getfield cmd : I
    //   328: iload #7
    //   330: iload #6
    //   332: aload #10
    //   334: invokevirtual obtainUpdateOp : (IIILjava/lang/Object;)Landroid/support/v7/widget/AdapterHelper$UpdateOp;
    //   337: astore_1
    //   338: aload_0
    //   339: aload_1
    //   340: iload_2
    //   341: invokevirtual dispatchFirstPassAndUpdateViewHolders : (Landroid/support/v7/widget/AdapterHelper$UpdateOp;I)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual recycleUpdateOp : (Landroid/support/v7/widget/AdapterHelper$UpdateOp;)V
    //   349: return
  }
  
  private void postponeAndUpdateViewHolders(UpdateOp paramUpdateOp) {
    this.mPostponedList.add(paramUpdateOp);
    switch (paramUpdateOp.cmd) {
      default:
        throw new IllegalArgumentException("Unknown update op type for " + paramUpdateOp);
      case 1:
        this.mCallback.offsetPositionsForAdd(paramUpdateOp.positionStart, paramUpdateOp.itemCount);
        return;
      case 8:
        this.mCallback.offsetPositionsForMove(paramUpdateOp.positionStart, paramUpdateOp.itemCount);
        return;
      case 2:
        this.mCallback.offsetPositionsForRemovingLaidOutOrNewView(paramUpdateOp.positionStart, paramUpdateOp.itemCount);
        return;
      case 4:
        break;
    } 
    this.mCallback.markViewHoldersUpdated(paramUpdateOp.positionStart, paramUpdateOp.itemCount, paramUpdateOp.payload);
  }
  
  private int updatePositionWithPostponed(int paramInt1, int paramInt2) {
    int i = this.mPostponedList.size() - 1;
    int j;
    for (j = paramInt1; i >= 0; j = paramInt1) {
      UpdateOp updateOp = this.mPostponedList.get(i);
      if (updateOp.cmd == 8) {
        int k;
        if (updateOp.positionStart < updateOp.itemCount) {
          k = updateOp.positionStart;
          paramInt1 = updateOp.itemCount;
        } else {
          k = updateOp.itemCount;
          paramInt1 = updateOp.positionStart;
        } 
        if (j >= k && j <= paramInt1) {
          if (k == updateOp.positionStart) {
            if (paramInt2 == 1) {
              updateOp.itemCount++;
            } else if (paramInt2 == 2) {
              updateOp.itemCount--;
            } 
            paramInt1 = j + 1;
          } else {
            if (paramInt2 == 1) {
              updateOp.positionStart++;
            } else if (paramInt2 == 2) {
              updateOp.positionStart--;
            } 
            paramInt1 = j - 1;
          } 
        } else {
          paramInt1 = j;
          if (j < updateOp.positionStart)
            if (paramInt2 == 1) {
              updateOp.positionStart++;
              updateOp.itemCount++;
              paramInt1 = j;
            } else {
              paramInt1 = j;
              if (paramInt2 == 2) {
                updateOp.positionStart--;
                updateOp.itemCount--;
                paramInt1 = j;
              } 
            }  
        } 
      } else if (updateOp.positionStart <= j) {
        if (updateOp.cmd == 1) {
          paramInt1 = j - updateOp.itemCount;
        } else {
          paramInt1 = j;
          if (updateOp.cmd == 2)
            paramInt1 = j + updateOp.itemCount; 
        } 
      } else if (paramInt2 == 1) {
        updateOp.positionStart++;
        paramInt1 = j;
      } else {
        paramInt1 = j;
        if (paramInt2 == 2) {
          updateOp.positionStart--;
          paramInt1 = j;
        } 
      } 
      i--;
    } 
    for (paramInt1 = this.mPostponedList.size() - 1; paramInt1 >= 0; paramInt1--) {
      UpdateOp updateOp = this.mPostponedList.get(paramInt1);
      if (updateOp.cmd == 8) {
        if (updateOp.itemCount == updateOp.positionStart || updateOp.itemCount < 0) {
          this.mPostponedList.remove(paramInt1);
          recycleUpdateOp(updateOp);
        } 
      } else if (updateOp.itemCount <= 0) {
        this.mPostponedList.remove(paramInt1);
        recycleUpdateOp(updateOp);
      } 
    } 
    return j;
  }
  
  AdapterHelper addUpdateOp(UpdateOp... paramVarArgs) {
    Collections.addAll(this.mPendingUpdates, paramVarArgs);
    return this;
  }
  
  public int applyPendingUpdatesToPosition(int paramInt) {
    int k = this.mPendingUpdates.size();
    int j = 0;
    int i = paramInt;
    while (true) {
      paramInt = i;
      if (j < k) {
        UpdateOp updateOp = this.mPendingUpdates.get(j);
        switch (updateOp.cmd) {
          case 1:
            paramInt = i;
            if (updateOp.positionStart <= i)
              paramInt = i + updateOp.itemCount; 
            j++;
            i = paramInt;
            break;
          case 2:
            paramInt = i;
            if (updateOp.positionStart <= i) {
              if (updateOp.positionStart + updateOp.itemCount > i)
                return -1; 
              paramInt = i - updateOp.itemCount;
            } 
            j++;
            i = paramInt;
            break;
          case 8:
            if (updateOp.positionStart == i) {
              paramInt = updateOp.itemCount;
            } else {
              int m = i;
              if (updateOp.positionStart < i)
                m = i - 1; 
              paramInt = m;
              if (updateOp.itemCount <= m)
                paramInt = m + 1; 
            } 
            j++;
            i = paramInt;
            break;
        } 
        continue;
      } 
      return paramInt;
    } 
  }
  
  void consumePostponedUpdates() {
    int j = this.mPostponedList.size();
    for (int i = 0; i < j; i++)
      this.mCallback.onDispatchSecondPass(this.mPostponedList.get(i)); 
    recycleUpdateOpsAndClearList(this.mPostponedList);
    this.mExistingUpdateTypes = 0;
  }
  
  void consumeUpdatesInOnePass() {
    consumePostponedUpdates();
    int j = this.mPendingUpdates.size();
    int i = 0;
    while (i < j) {
      UpdateOp updateOp = this.mPendingUpdates.get(i);
      switch (updateOp.cmd) {
        case 1:
          this.mCallback.onDispatchSecondPass(updateOp);
          this.mCallback.offsetPositionsForAdd(updateOp.positionStart, updateOp.itemCount);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 2:
          this.mCallback.onDispatchSecondPass(updateOp);
          this.mCallback.offsetPositionsForRemovingInvisible(updateOp.positionStart, updateOp.itemCount);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 4:
          this.mCallback.onDispatchSecondPass(updateOp);
          this.mCallback.markViewHoldersUpdated(updateOp.positionStart, updateOp.itemCount, updateOp.payload);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 8:
          this.mCallback.onDispatchSecondPass(updateOp);
          this.mCallback.offsetPositionsForMove(updateOp.positionStart, updateOp.itemCount);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
      } 
    } 
    recycleUpdateOpsAndClearList(this.mPendingUpdates);
    this.mExistingUpdateTypes = 0;
  }
  
  void dispatchFirstPassAndUpdateViewHolders(UpdateOp paramUpdateOp, int paramInt) {
    this.mCallback.onDispatchFirstPass(paramUpdateOp);
    switch (paramUpdateOp.cmd) {
      default:
        throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
      case 2:
        this.mCallback.offsetPositionsForRemovingInvisible(paramInt, paramUpdateOp.itemCount);
        return;
      case 4:
        break;
    } 
    this.mCallback.markViewHoldersUpdated(paramInt, paramUpdateOp.itemCount, paramUpdateOp.payload);
  }
  
  int findPositionOffset(int paramInt) {
    return findPositionOffset(paramInt, 0);
  }
  
  int findPositionOffset(int paramInt1, int paramInt2) {
    int j = this.mPostponedList.size();
    int i = paramInt2;
    paramInt2 = paramInt1;
    while (true) {
      paramInt1 = paramInt2;
      if (i < j) {
        UpdateOp updateOp = this.mPostponedList.get(i);
        if (updateOp.cmd == 8) {
          if (updateOp.positionStart == paramInt2) {
            paramInt1 = updateOp.itemCount;
          } else {
            int k = paramInt2;
            if (updateOp.positionStart < paramInt2)
              k = paramInt2 - 1; 
            paramInt1 = k;
            if (updateOp.itemCount <= k)
              paramInt1 = k + 1; 
          } 
        } else {
          paramInt1 = paramInt2;
          if (updateOp.positionStart <= paramInt2)
            if (updateOp.cmd == 2) {
              if (paramInt2 < updateOp.positionStart + updateOp.itemCount)
                return -1; 
              paramInt1 = paramInt2 - updateOp.itemCount;
            } else {
              paramInt1 = paramInt2;
              if (updateOp.cmd == 1)
                paramInt1 = paramInt2 + updateOp.itemCount; 
            }  
        } 
        i++;
        paramInt2 = paramInt1;
        continue;
      } 
      return paramInt1;
    } 
  }
  
  boolean hasAnyUpdateTypes(int paramInt) {
    return ((this.mExistingUpdateTypes & paramInt) != 0);
  }
  
  boolean hasPendingUpdates() {
    return (this.mPendingUpdates.size() > 0);
  }
  
  boolean hasUpdates() {
    return (!this.mPostponedList.isEmpty() && !this.mPendingUpdates.isEmpty());
  }
  
  public UpdateOp obtainUpdateOp(int paramInt1, int paramInt2, int paramInt3, Object paramObject) {
    UpdateOp updateOp = (UpdateOp)this.mUpdateOpPool.acquire();
    if (updateOp == null)
      return new UpdateOp(paramInt1, paramInt2, paramInt3, paramObject); 
    updateOp.cmd = paramInt1;
    updateOp.positionStart = paramInt2;
    updateOp.itemCount = paramInt3;
    updateOp.payload = paramObject;
    return updateOp;
  }
  
  boolean onItemRangeChanged(int paramInt1, int paramInt2, Object paramObject) {
    boolean bool = true;
    if (paramInt2 < 1)
      return false; 
    this.mPendingUpdates.add(obtainUpdateOp(4, paramInt1, paramInt2, paramObject));
    this.mExistingUpdateTypes |= 0x4;
    if (this.mPendingUpdates.size() != 1)
      bool = false; 
    return bool;
  }
  
  boolean onItemRangeInserted(int paramInt1, int paramInt2) {
    boolean bool = true;
    if (paramInt2 < 1)
      return false; 
    this.mPendingUpdates.add(obtainUpdateOp(1, paramInt1, paramInt2, null));
    this.mExistingUpdateTypes |= 0x1;
    if (this.mPendingUpdates.size() != 1)
      bool = false; 
    return bool;
  }
  
  boolean onItemRangeMoved(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = true;
    if (paramInt1 == paramInt2)
      return false; 
    if (paramInt3 != 1)
      throw new IllegalArgumentException("Moving more than 1 item is not supported yet"); 
    this.mPendingUpdates.add(obtainUpdateOp(8, paramInt1, paramInt2, null));
    this.mExistingUpdateTypes |= 0x8;
    if (this.mPendingUpdates.size() != 1)
      bool = false; 
    return bool;
  }
  
  boolean onItemRangeRemoved(int paramInt1, int paramInt2) {
    boolean bool = true;
    if (paramInt2 < 1)
      return false; 
    this.mPendingUpdates.add(obtainUpdateOp(2, paramInt1, paramInt2, null));
    this.mExistingUpdateTypes |= 0x2;
    if (this.mPendingUpdates.size() != 1)
      bool = false; 
    return bool;
  }
  
  void preProcess() {
    this.mOpReorderer.reorderOps(this.mPendingUpdates);
    int j = this.mPendingUpdates.size();
    int i = 0;
    while (i < j) {
      UpdateOp updateOp = this.mPendingUpdates.get(i);
      switch (updateOp.cmd) {
        case 1:
          applyAdd(updateOp);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 2:
          applyRemove(updateOp);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 4:
          applyUpdate(updateOp);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
        case 8:
          applyMove(updateOp);
          if (this.mOnItemProcessedCallback != null)
            this.mOnItemProcessedCallback.run(); 
          i++;
          break;
      } 
    } 
    this.mPendingUpdates.clear();
  }
  
  public void recycleUpdateOp(UpdateOp paramUpdateOp) {
    if (!this.mDisableRecycler) {
      paramUpdateOp.payload = null;
      this.mUpdateOpPool.release(paramUpdateOp);
    } 
  }
  
  void recycleUpdateOpsAndClearList(List<UpdateOp> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++)
      recycleUpdateOp(paramList.get(i)); 
    paramList.clear();
  }
  
  void reset() {
    recycleUpdateOpsAndClearList(this.mPendingUpdates);
    recycleUpdateOpsAndClearList(this.mPostponedList);
    this.mExistingUpdateTypes = 0;
  }
  
  static interface Callback {
    RecyclerView.ViewHolder findViewHolder(int param1Int);
    
    void markViewHoldersUpdated(int param1Int1, int param1Int2, Object param1Object);
    
    void offsetPositionsForAdd(int param1Int1, int param1Int2);
    
    void offsetPositionsForMove(int param1Int1, int param1Int2);
    
    void offsetPositionsForRemovingInvisible(int param1Int1, int param1Int2);
    
    void offsetPositionsForRemovingLaidOutOrNewView(int param1Int1, int param1Int2);
    
    void onDispatchFirstPass(AdapterHelper.UpdateOp param1UpdateOp);
    
    void onDispatchSecondPass(AdapterHelper.UpdateOp param1UpdateOp);
  }
  
  static class UpdateOp {
    static final int ADD = 1;
    
    static final int MOVE = 8;
    
    static final int POOL_SIZE = 30;
    
    static final int REMOVE = 2;
    
    static final int UPDATE = 4;
    
    int cmd;
    
    int itemCount;
    
    Object payload;
    
    int positionStart;
    
    UpdateOp(int param1Int1, int param1Int2, int param1Int3, Object param1Object) {
      this.cmd = param1Int1;
      this.positionStart = param1Int2;
      this.itemCount = param1Int3;
      this.payload = param1Object;
    }
    
    String cmdToString() {
      switch (this.cmd) {
        default:
          return "??";
        case 1:
          return "add";
        case 2:
          return "rm";
        case 4:
          return "up";
        case 8:
          break;
      } 
      return "mv";
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object == null || getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        if (this.cmd != ((UpdateOp)param1Object).cmd)
          return false; 
        if (this.cmd != 8 || Math.abs(this.itemCount - this.positionStart) != 1 || this.itemCount != ((UpdateOp)param1Object).positionStart || this.positionStart != ((UpdateOp)param1Object).itemCount) {
          if (this.itemCount != ((UpdateOp)param1Object).itemCount)
            return false; 
          if (this.positionStart != ((UpdateOp)param1Object).positionStart)
            return false; 
          if (this.payload != null)
            return !!this.payload.equals(((UpdateOp)param1Object).payload); 
          if (((UpdateOp)param1Object).payload != null)
            return false; 
        } 
      } 
      return true;
    }
    
    public int hashCode() {
      return (this.cmd * 31 + this.positionStart) * 31 + this.itemCount;
    }
    
    public String toString() {
      return Integer.toHexString(System.identityHashCode(this)) + "[" + cmdToString() + ",s:" + this.positionStart + "c:" + this.itemCount + ",p:" + this.payload + "]";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\support\v7\widget\AdapterHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */