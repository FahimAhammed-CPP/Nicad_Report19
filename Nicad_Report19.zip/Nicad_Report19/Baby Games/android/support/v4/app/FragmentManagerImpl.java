package android.support.v4.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.arch.lifecycle.ViewModelStore;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.v4.util.ArraySet;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final Interpolator ACCELERATE_CUBIC;
  
  static final Interpolator ACCELERATE_QUINT;
  
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT;
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  static Field sAnimationListenerField = null;
  
  SparseArray<Fragment> mActive;
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>> mLifecycleCallbacks = new CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  String mNoTransactionsBecause;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  FragmentManagerNonConfig mSavedNonConfig;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  boolean mStopped;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = (Interpolator)new AccelerateInterpolator(2.5F);
    ACCELERATE_CUBIC = (Interpolator)new AccelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    if (this.mCurState >= 1) {
      int j = Math.min(this.mCurState, 4);
      int k = this.mAdded.size();
      int i = 0;
      while (true) {
        if (i < k) {
          Fragment fragment = this.mAdded.get(i);
          if (fragment.mState < j) {
            moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
            if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
              paramArraySet.add(fragment); 
          } 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private void animateRemoveFragment(@NonNull final Fragment fragment, @NonNull AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    final View viewToAnimate = fragment.mView;
    final ViewGroup container = fragment.mContainer;
    viewGroup.startViewTransition(view);
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      EndViewTransitionAnimator endViewTransitionAnimator = new EndViewTransitionAnimator(paramAnimationOrAnimator.animation, viewGroup, view);
      fragment.setAnimatingAway(fragment.mView);
      endViewTransitionAnimator.setAnimationListener(new AnimationListenerWrapper(getAnimationListener((Animation)endViewTransitionAnimator)) {
            public void onAnimationEnd(Animation param1Animation) {
              super.onAnimationEnd(param1Animation);
              container.post(new Runnable() {
                    public void run() {
                      if (fragment.getAnimatingAway() != null) {
                        fragment.setAnimatingAway(null);
                        FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
          });
      setHWLayerAnimListenerIfAlpha(view, paramAnimationOrAnimator);
      fragment.mView.startAnimation((Animation)endViewTransitionAnimator);
      return;
    } 
    Animator animator = paramAnimationOrAnimator.animator;
    fragment.setAnimator(paramAnimationOrAnimator.animator);
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            container.endViewTransition(viewToAnimate);
            param1Animator = fragment.getAnimator();
            fragment.setAnimator(null);
            if (param1Animator != null && container.indexOfChild(viewToAnimate) < 0)
              FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false); 
          }
        });
    animator.setTarget(fragment.mView);
    setHWLayerAnimListenerIfAlpha(fragment.mView, paramAnimationOrAnimator);
    animator.start();
  }
  
  private void burpActive() {
    if (this.mActive != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        if (this.mActive.valueAt(i) == null)
          this.mActive.delete(this.mActive.keyAt(i)); 
      }  
  }
  
  private void checkStateLoss() {
    if (isStateSaved())
      throw new IllegalStateException("Can not perform this action after onSaveInstanceState"); 
    if (this.mNoTransactionsBecause != null)
      throw new IllegalStateException("Can not perform this action inside of " + this.mNoTransactionsBecause); 
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    if (this.mActive != null) {
      int j = this.mActive.size();
      for (int i = 0; i < j; i++) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
          if (fragment.mPostponedAlpha > 0.0F)
            fragment.mView.setAlpha(fragment.mPostponedAlpha); 
          if (paramBoolean3) {
            fragment.mPostponedAlpha = 0.0F;
          } else {
            fragment.mPostponedAlpha = -1.0F;
            fragment.mIsNewlyAdded = false;
          } 
        } 
      } 
    } 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    int i;
    if (this.mActive == null) {
      i = 0;
    } else {
      i = this.mActive.size();
    } 
    for (int j = 0; j < i; j++) {
      Fragment fragment = (Fragment)this.mActive.valueAt(j);
      if (fragment != null)
        if (fragment.getAnimatingAway() != null) {
          int k = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          moveToState(fragment, k, 0, 0, false);
        } else if (fragment.getAnimator() != null) {
          fragment.getAnimator().end();
        }  
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (this.mExecutingActions)
      throw new IllegalStateException("FragmentManager is already executing transactions"); 
    if (this.mHost == null)
      throw new IllegalStateException("Fragment host has been destroyed"); 
    if (Looper.myLooper() != this.mHost.getHandler().getLooper())
      throw new IllegalStateException("Must be called from main thread of fragment host"); 
    if (!paramBoolean)
      checkStateLoss(); 
    if (this.mTmpRecords == null) {
      this.mTmpRecords = new ArrayList<BackStackRecord>();
      this.mTmpIsPop = new ArrayList<Boolean>();
    } 
    this.mExecutingActions = true;
    try {
      executePostponedTransaction(null, null);
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue()) {
        boolean bool;
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 == paramInt2 - 1) {
          bool = true;
        } else {
          bool = false;
        } 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((BackStackRecord)paramArrayList.get(paramInt1)).mReorderingAllowed;
    boolean bool = false;
    if (this.mTmpAddedFragments == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      this.mTmpAddedFragments.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    i = paramInt2;
    if (bool1) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      i = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } 
    if (i != paramInt1 && bool1) {
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, i, true);
      moveToState(this.mCurState, true);
    } 
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      paramInt1++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: ifnonnull -> 105
    //   7: iconst_0
    //   8: istore_3
    //   9: iconst_0
    //   10: istore #5
    //   12: iload_3
    //   13: istore #4
    //   15: iload #5
    //   17: istore_3
    //   18: iload_3
    //   19: iload #4
    //   21: if_icmpge -> 236
    //   24: aload_0
    //   25: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   28: iload_3
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast android/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener
    //   35: astore #7
    //   37: aload_1
    //   38: ifnull -> 116
    //   41: aload #7
    //   43: invokestatic access$300 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Z
    //   46: ifne -> 116
    //   49: aload_1
    //   50: aload #7
    //   52: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   55: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   58: istore #5
    //   60: iload #5
    //   62: iconst_m1
    //   63: if_icmpeq -> 116
    //   66: aload_2
    //   67: iload #5
    //   69: invokevirtual get : (I)Ljava/lang/Object;
    //   72: checkcast java/lang/Boolean
    //   75: invokevirtual booleanValue : ()Z
    //   78: ifeq -> 116
    //   81: aload #7
    //   83: invokevirtual cancelTransaction : ()V
    //   86: iload #4
    //   88: istore #6
    //   90: iload_3
    //   91: istore #5
    //   93: iload #5
    //   95: iconst_1
    //   96: iadd
    //   97: istore_3
    //   98: iload #6
    //   100: istore #4
    //   102: goto -> 18
    //   105: aload_0
    //   106: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   109: invokevirtual size : ()I
    //   112: istore_3
    //   113: goto -> 9
    //   116: aload #7
    //   118: invokevirtual isReady : ()Z
    //   121: ifne -> 159
    //   124: iload_3
    //   125: istore #5
    //   127: iload #4
    //   129: istore #6
    //   131: aload_1
    //   132: ifnull -> 93
    //   135: iload_3
    //   136: istore #5
    //   138: iload #4
    //   140: istore #6
    //   142: aload #7
    //   144: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   147: aload_1
    //   148: iconst_0
    //   149: aload_1
    //   150: invokevirtual size : ()I
    //   153: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   156: ifeq -> 93
    //   159: aload_0
    //   160: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   163: iload_3
    //   164: invokevirtual remove : (I)Ljava/lang/Object;
    //   167: pop
    //   168: iload_3
    //   169: iconst_1
    //   170: isub
    //   171: istore #5
    //   173: iload #4
    //   175: iconst_1
    //   176: isub
    //   177: istore #6
    //   179: aload_1
    //   180: ifnull -> 228
    //   183: aload #7
    //   185: invokestatic access$300 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Z
    //   188: ifne -> 228
    //   191: aload_1
    //   192: aload #7
    //   194: invokestatic access$400 : (Landroid/support/v4/app/FragmentManagerImpl$StartEnterTransitionListener;)Landroid/support/v4/app/BackStackRecord;
    //   197: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   200: istore_3
    //   201: iload_3
    //   202: iconst_m1
    //   203: if_icmpeq -> 228
    //   206: aload_2
    //   207: iload_3
    //   208: invokevirtual get : (I)Ljava/lang/Object;
    //   211: checkcast java/lang/Boolean
    //   214: invokevirtual booleanValue : ()Z
    //   217: ifeq -> 228
    //   220: aload #7
    //   222: invokevirtual cancelTransaction : ()V
    //   225: goto -> 93
    //   228: aload #7
    //   230: invokevirtual completeTransaction : ()V
    //   233: goto -> 93
    //   236: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup == null || view == null)
      return null; 
    for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mContainer == viewGroup) {
        paramFragment = fragment;
        if (fragment.mView == null)
          continue; 
        return paramFragment;
      } 
      continue;
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: aload_0
    //   4: monitorenter
    //   5: aload_0
    //   6: getfield mPendingActions : Ljava/util/ArrayList;
    //   9: ifnull -> 22
    //   12: aload_0
    //   13: getfield mPendingActions : Ljava/util/ArrayList;
    //   16: invokevirtual size : ()I
    //   19: ifne -> 26
    //   22: aload_0
    //   23: monitorexit
    //   24: iconst_0
    //   25: ireturn
    //   26: aload_0
    //   27: getfield mPendingActions : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: istore #4
    //   35: iconst_0
    //   36: istore_3
    //   37: iload_3
    //   38: iload #4
    //   40: if_icmpge -> 73
    //   43: iload #5
    //   45: aload_0
    //   46: getfield mPendingActions : Ljava/util/ArrayList;
    //   49: iload_3
    //   50: invokevirtual get : (I)Ljava/lang/Object;
    //   53: checkcast android/support/v4/app/FragmentManagerImpl$OpGenerator
    //   56: aload_1
    //   57: aload_2
    //   58: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   63: ior
    //   64: istore #5
    //   66: iload_3
    //   67: iconst_1
    //   68: iadd
    //   69: istore_3
    //   70: goto -> 37
    //   73: aload_0
    //   74: getfield mPendingActions : Ljava/util/ArrayList;
    //   77: invokevirtual clear : ()V
    //   80: aload_0
    //   81: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   84: invokevirtual getHandler : ()Landroid/os/Handler;
    //   87: aload_0
    //   88: getfield mExecCommit : Ljava/lang/Runnable;
    //   91: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   94: aload_0
    //   95: monitorexit
    //   96: iload #5
    //   98: ireturn
    //   99: astore_1
    //   100: aload_0
    //   101: monitorexit
    //   102: aload_1
    //   103: athrow
    // Exception table:
    //   from	to	target	type
    //   5	22	99	finally
    //   22	24	99	finally
    //   26	35	99	finally
    //   43	66	99	finally
    //   73	96	99	finally
    //   100	102	99	finally
  }
  
  private static Animation.AnimationListener getAnimationListener(Animation paramAnimation) {
    try {
      if (sAnimationListenerField == null) {
        sAnimationListenerField = Animation.class.getDeclaredField("mListener");
        sAnimationListenerField.setAccessible(true);
      } 
      return (Animation.AnimationListener)sAnimationListenerField.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException);
      return null;
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException);
      return null;
    } 
  }
  
  static AnimationOrAnimator makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.getView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  static boolean modifiesAlpha(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (int i = 0; i < arrayOfPropertyValuesHolder.length; i++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[i].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (int i = 0; i < arrayList.size(); i++) {
        if (modifiesAlpha(arrayList.get(i)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean modifiesAlpha(AnimationOrAnimator paramAnimationOrAnimator) {
    List list;
    if (paramAnimationOrAnimator.animation instanceof AlphaAnimation)
      return true; 
    if (paramAnimationOrAnimator.animation instanceof AnimationSet) {
      list = ((AnimationSet)paramAnimationOrAnimator.animation).getAnimations();
      for (int i = 0; i < list.size(); i++) {
        if (list.get(i) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return modifiesAlpha(((AnimationOrAnimator)list).animator);
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    if (this.mPrimaryNav != null && paramInt1 < 0 && paramString == null) {
      FragmentManager fragmentManager = this.mPrimaryNav.peekChildFragmentManager();
      if (fragmentManager != null && fragmentManager.popBackStackImmediate())
        return true; 
    } 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
        doPendingDeferredStart();
        return bool;
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int j = paramInt2;
    int i = paramInt2 - 1;
    while (i >= paramInt1) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
      j = k;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null && !paramArrayList.isEmpty()) {
      if (paramArrayList1 == null || paramArrayList.size() != paramArrayList1.size())
        throw new IllegalStateException("Internal error with the back stack records"); 
      executePostponedTransaction(paramArrayList, paramArrayList1);
      int k = paramArrayList.size();
      int j = 0;
      int i = 0;
      while (i < k) {
        int n = i;
        int m = j;
        if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
          if (j != i)
            executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
          j = i + 1;
          m = j;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              m = j;
              if (j < k) {
                m = j;
                if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                  m = j;
                  if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                    j++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          executeOpsTogether(paramArrayList, paramArrayList1, i, m);
          i = m;
          n = m - 1;
          m = i;
        } 
        i = n + 1;
        j = m;
      } 
      if (j != k) {
        executeOpsTogether(paramArrayList, paramArrayList1, j, k);
        return;
      } 
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    switch (paramInt) {
      default:
        return 0;
      case 4097:
        return 8194;
      case 8194:
        return 4097;
      case 4099:
        break;
    } 
    return 4099;
  }
  
  private void scheduleCommit() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   8: ifnull -> 92
    //   11: aload_0
    //   12: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   15: invokevirtual isEmpty : ()Z
    //   18: ifne -> 92
    //   21: iconst_1
    //   22: istore_1
    //   23: aload_0
    //   24: getfield mPendingActions : Ljava/util/ArrayList;
    //   27: ifnull -> 97
    //   30: aload_0
    //   31: getfield mPendingActions : Ljava/util/ArrayList;
    //   34: invokevirtual size : ()I
    //   37: iconst_1
    //   38: if_icmpne -> 97
    //   41: goto -> 81
    //   44: aload_0
    //   45: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   48: invokevirtual getHandler : ()Landroid/os/Handler;
    //   51: aload_0
    //   52: getfield mExecCommit : Ljava/lang/Runnable;
    //   55: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   58: aload_0
    //   59: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   62: invokevirtual getHandler : ()Landroid/os/Handler;
    //   65: aload_0
    //   66: getfield mExecCommit : Ljava/lang/Runnable;
    //   69: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   72: pop
    //   73: aload_0
    //   74: monitorexit
    //   75: return
    //   76: astore_3
    //   77: aload_0
    //   78: monitorexit
    //   79: aload_3
    //   80: athrow
    //   81: iload_1
    //   82: ifne -> 44
    //   85: iload_2
    //   86: ifeq -> 73
    //   89: goto -> 44
    //   92: iconst_0
    //   93: istore_1
    //   94: goto -> 23
    //   97: iconst_0
    //   98: istore_2
    //   99: goto -> 81
    // Exception table:
    //   from	to	target	type
    //   4	21	76	finally
    //   23	41	76	finally
    //   44	73	76	finally
    //   73	75	76	finally
    //   77	79	76	finally
  }
  
  private static void setHWLayerAnimListenerIfAlpha(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramView != null && paramAnimationOrAnimator != null && shouldRunOnHWLayer(paramView, paramAnimationOrAnimator)) {
      if (paramAnimationOrAnimator.animator != null) {
        paramAnimationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorOnHWLayerIfNeededListener(paramView));
        return;
      } 
      Animation.AnimationListener animationListener = getAnimationListener(paramAnimationOrAnimator.animation);
      paramView.setLayerType(2, null);
      paramAnimationOrAnimator.animation.setAnimationListener(new AnimateOnHWLayerIfNeededListener(paramView, animationListener));
      return;
    } 
  }
  
  private static void setRetaining(FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramFragmentManagerNonConfig != null) {
      List<Fragment> list1 = paramFragmentManagerNonConfig.getFragments();
      if (list1 != null) {
        Iterator<Fragment> iterator = list1.iterator();
        while (iterator.hasNext())
          ((Fragment)iterator.next()).mRetaining = true; 
      } 
      List<FragmentManagerNonConfig> list = paramFragmentManagerNonConfig.getChildNonConfigs();
      if (list != null) {
        Iterator<FragmentManagerNonConfig> iterator = list.iterator();
        while (true) {
          if (iterator.hasNext()) {
            setRetaining(iterator.next());
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  static boolean shouldRunOnHWLayer(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    return (paramView != null && paramAnimationOrAnimator != null && Build.VERSION.SDK_INT >= 19 && paramView.getLayerType() == 0 && ViewCompat.hasOverlappingRendering(paramView) && modifiesAlpha(paramAnimationOrAnimator));
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    if (this.mHost != null) {
      try {
        this.mHost.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
      throw paramRuntimeException;
    } 
    try {
      dump("  ", null, (PrintWriter)exception, new String[0]);
    } catch (Exception exception1) {
      Log.e("FragmentManager", "Failed dumping state", exception1);
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    switch (paramInt) {
      default:
        return -1;
      case 4097:
        return paramBoolean ? 1 : 2;
      case 8194:
        return paramBoolean ? 3 : 4;
      case 4099:
        break;
    } 
    return paramBoolean ? 5 : 6;
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG)
      Log.v("FragmentManager", "add: " + paramFragment); 
    makeActive(paramFragment);
    if (!paramFragment.mDetached) {
      if (this.mAdded.contains(paramFragment))
        throw new IllegalStateException("Fragment already added: " + paramFragment); 
      synchronized (this.mAdded) {
        this.mAdded.add(paramFragment);
        paramFragment.mAdded = true;
        paramFragment.mRemoving = false;
        if (paramFragment.mView == null)
          paramFragment.mHiddenChanged = false; 
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        if (paramBoolean)
          moveToState(paramFragment); 
        return;
      } 
    } 
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 19
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 100
    //   19: aload_0
    //   20: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   23: ifnonnull -> 37
    //   26: aload_0
    //   27: new java/util/ArrayList
    //   30: dup
    //   31: invokespecial <init> : ()V
    //   34: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   37: aload_0
    //   38: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   41: invokevirtual size : ()I
    //   44: istore_2
    //   45: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   48: ifeq -> 87
    //   51: ldc 'FragmentManager'
    //   53: new java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: ldc_w 'Setting back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: iload_2
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: ldc_w ' to '
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: aload_1
    //   77: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   80: invokevirtual toString : ()Ljava/lang/String;
    //   83: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   86: pop
    //   87: aload_0
    //   88: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   91: aload_1
    //   92: invokevirtual add : (Ljava/lang/Object;)Z
    //   95: pop
    //   96: aload_0
    //   97: monitorexit
    //   98: iload_2
    //   99: ireturn
    //   100: aload_0
    //   101: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   104: aload_0
    //   105: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   108: invokevirtual size : ()I
    //   111: iconst_1
    //   112: isub
    //   113: invokevirtual remove : (I)Ljava/lang/Object;
    //   116: checkcast java/lang/Integer
    //   119: invokevirtual intValue : ()I
    //   122: istore_2
    //   123: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   126: ifeq -> 165
    //   129: ldc 'FragmentManager'
    //   131: new java/lang/StringBuilder
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: ldc_w 'Adding back stack index '
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: iload_2
    //   145: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   148: ldc_w ' with '
    //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: aload_1
    //   155: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   158: invokevirtual toString : ()Ljava/lang/String;
    //   161: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   164: pop
    //   165: aload_0
    //   166: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   169: iload_2
    //   170: aload_1
    //   171: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   174: pop
    //   175: aload_0
    //   176: monitorexit
    //   177: iload_2
    //   178: ireturn
    //   179: astore_1
    //   180: aload_0
    //   181: monitorexit
    //   182: aload_1
    //   183: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	179	finally
    //   19	37	179	finally
    //   37	87	179	finally
    //   87	98	179	finally
    //   100	165	179	finally
    //   165	177	179	finally
    //   180	182	179	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost != null)
      throw new IllegalStateException("Already attached"); 
    this.mHost = paramFragmentHostCallback;
    this.mContainer = paramFragmentContainer;
    this.mParent = paramFragment;
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG)
      Log.v("FragmentManager", "attach: " + paramFragment); 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        if (this.mAdded.contains(paramFragment))
          throw new IllegalStateException("Fragment already added: " + paramFragment); 
        if (DEBUG)
          Log.v("FragmentManager", "add from attach: " + paramFragment); 
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          return;
        } 
      } 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      boolean bool;
      int i = fragment.getNextTransition();
      if (!fragment.mHidden) {
        bool = true;
      } else {
        bool = false;
      } 
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, i, bool, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
        animationOrAnimator.animator.start();
      } else {
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          i = 8;
        } else {
          i = 0;
        } 
        fragment.mView.setVisibility(i);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && fragment.mHasMenu && fragment.mMenuVisible)
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG)
      Log.v("FragmentManager", "detach: " + paramFragment); 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG)
          Log.v("FragmentManager", "remove from detach: " + paramFragment); 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState >= 1) {
      int i = 0;
      while (true) {
        if (i < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(i);
          if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
            return true; 
          i++;
          continue;
        } 
        return false;
      } 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    if (this.mCurState < 1)
      return false; 
    boolean bool = false;
    ArrayList<Fragment> arrayList = null;
    int i = 0;
    while (i < this.mAdded.size()) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool1 = bool;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool1 = bool;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          bool1 = true;
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
        } 
      } 
      i++;
      arrayList = arrayList1;
      bool = bool1;
    } 
    if (this.mCreatedMenus != null)
      for (i = 0; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    if (this.mParent != null) {
      FragmentManager fragmentManager = this.mParent.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState >= 1) {
      int i = 0;
      while (true) {
        if (i < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(i);
          if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
            return true; 
          i++;
          continue;
        } 
        return false;
      } 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState >= 1) {
      int i = 0;
      while (true) {
        if (i < this.mAdded.size()) {
          Fragment fragment = this.mAdded.get(i);
          if (fragment != null)
            fragment.performOptionsMenuClosed(paramMenu); 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(4);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    if (this.mCurState < 1)
      return false; 
    boolean bool = false;
    int i = 0;
    while (true) {
      boolean bool1 = bool;
      if (i < this.mAdded.size()) {
        Fragment fragment = this.mAdded.get(i);
        bool1 = bool;
        if (fragment != null) {
          bool1 = bool;
          if (fragment.performPrepareOptionsMenu(paramMenu))
            bool1 = true; 
        } 
        i++;
        bool = bool1;
        continue;
      } 
      return bool1;
    } 
  }
  
  public void dispatchReallyStop() {
    dispatchStateChange(2);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(5);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStop() {
    this.mStopped = true;
    dispatchStateChange(3);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: aload_1
    //   8: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   11: ldc_w '    '
    //   14: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: invokevirtual toString : ()Ljava/lang/String;
    //   20: astore #7
    //   22: aload_0
    //   23: getfield mActive : Landroid/util/SparseArray;
    //   26: ifnull -> 153
    //   29: aload_0
    //   30: getfield mActive : Landroid/util/SparseArray;
    //   33: invokevirtual size : ()I
    //   36: istore #6
    //   38: iload #6
    //   40: ifle -> 153
    //   43: aload_3
    //   44: aload_1
    //   45: invokevirtual print : (Ljava/lang/String;)V
    //   48: aload_3
    //   49: ldc_w 'Active Fragments in '
    //   52: invokevirtual print : (Ljava/lang/String;)V
    //   55: aload_3
    //   56: aload_0
    //   57: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   60: invokestatic toHexString : (I)Ljava/lang/String;
    //   63: invokevirtual print : (Ljava/lang/String;)V
    //   66: aload_3
    //   67: ldc_w ':'
    //   70: invokevirtual println : (Ljava/lang/String;)V
    //   73: iconst_0
    //   74: istore #5
    //   76: iload #5
    //   78: iload #6
    //   80: if_icmpge -> 153
    //   83: aload_0
    //   84: getfield mActive : Landroid/util/SparseArray;
    //   87: iload #5
    //   89: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   92: checkcast android/support/v4/app/Fragment
    //   95: astore #8
    //   97: aload_3
    //   98: aload_1
    //   99: invokevirtual print : (Ljava/lang/String;)V
    //   102: aload_3
    //   103: ldc_w '  #'
    //   106: invokevirtual print : (Ljava/lang/String;)V
    //   109: aload_3
    //   110: iload #5
    //   112: invokevirtual print : (I)V
    //   115: aload_3
    //   116: ldc_w ': '
    //   119: invokevirtual print : (Ljava/lang/String;)V
    //   122: aload_3
    //   123: aload #8
    //   125: invokevirtual println : (Ljava/lang/Object;)V
    //   128: aload #8
    //   130: ifnull -> 144
    //   133: aload #8
    //   135: aload #7
    //   137: aload_2
    //   138: aload_3
    //   139: aload #4
    //   141: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   144: iload #5
    //   146: iconst_1
    //   147: iadd
    //   148: istore #5
    //   150: goto -> 76
    //   153: aload_0
    //   154: getfield mAdded : Ljava/util/ArrayList;
    //   157: invokevirtual size : ()I
    //   160: istore #6
    //   162: iload #6
    //   164: ifle -> 246
    //   167: aload_3
    //   168: aload_1
    //   169: invokevirtual print : (Ljava/lang/String;)V
    //   172: aload_3
    //   173: ldc_w 'Added Fragments:'
    //   176: invokevirtual println : (Ljava/lang/String;)V
    //   179: iconst_0
    //   180: istore #5
    //   182: iload #5
    //   184: iload #6
    //   186: if_icmpge -> 246
    //   189: aload_0
    //   190: getfield mAdded : Ljava/util/ArrayList;
    //   193: iload #5
    //   195: invokevirtual get : (I)Ljava/lang/Object;
    //   198: checkcast android/support/v4/app/Fragment
    //   201: astore #8
    //   203: aload_3
    //   204: aload_1
    //   205: invokevirtual print : (Ljava/lang/String;)V
    //   208: aload_3
    //   209: ldc_w '  #'
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: iload #5
    //   218: invokevirtual print : (I)V
    //   221: aload_3
    //   222: ldc_w ': '
    //   225: invokevirtual print : (Ljava/lang/String;)V
    //   228: aload_3
    //   229: aload #8
    //   231: invokevirtual toString : ()Ljava/lang/String;
    //   234: invokevirtual println : (Ljava/lang/String;)V
    //   237: iload #5
    //   239: iconst_1
    //   240: iadd
    //   241: istore #5
    //   243: goto -> 182
    //   246: aload_0
    //   247: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   250: ifnull -> 346
    //   253: aload_0
    //   254: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   257: invokevirtual size : ()I
    //   260: istore #6
    //   262: iload #6
    //   264: ifle -> 346
    //   267: aload_3
    //   268: aload_1
    //   269: invokevirtual print : (Ljava/lang/String;)V
    //   272: aload_3
    //   273: ldc_w 'Fragments Created Menus:'
    //   276: invokevirtual println : (Ljava/lang/String;)V
    //   279: iconst_0
    //   280: istore #5
    //   282: iload #5
    //   284: iload #6
    //   286: if_icmpge -> 346
    //   289: aload_0
    //   290: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   293: iload #5
    //   295: invokevirtual get : (I)Ljava/lang/Object;
    //   298: checkcast android/support/v4/app/Fragment
    //   301: astore #8
    //   303: aload_3
    //   304: aload_1
    //   305: invokevirtual print : (Ljava/lang/String;)V
    //   308: aload_3
    //   309: ldc_w '  #'
    //   312: invokevirtual print : (Ljava/lang/String;)V
    //   315: aload_3
    //   316: iload #5
    //   318: invokevirtual print : (I)V
    //   321: aload_3
    //   322: ldc_w ': '
    //   325: invokevirtual print : (Ljava/lang/String;)V
    //   328: aload_3
    //   329: aload #8
    //   331: invokevirtual toString : ()Ljava/lang/String;
    //   334: invokevirtual println : (Ljava/lang/String;)V
    //   337: iload #5
    //   339: iconst_1
    //   340: iadd
    //   341: istore #5
    //   343: goto -> 282
    //   346: aload_0
    //   347: getfield mBackStack : Ljava/util/ArrayList;
    //   350: ifnull -> 457
    //   353: aload_0
    //   354: getfield mBackStack : Ljava/util/ArrayList;
    //   357: invokevirtual size : ()I
    //   360: istore #6
    //   362: iload #6
    //   364: ifle -> 457
    //   367: aload_3
    //   368: aload_1
    //   369: invokevirtual print : (Ljava/lang/String;)V
    //   372: aload_3
    //   373: ldc_w 'Back Stack:'
    //   376: invokevirtual println : (Ljava/lang/String;)V
    //   379: iconst_0
    //   380: istore #5
    //   382: iload #5
    //   384: iload #6
    //   386: if_icmpge -> 457
    //   389: aload_0
    //   390: getfield mBackStack : Ljava/util/ArrayList;
    //   393: iload #5
    //   395: invokevirtual get : (I)Ljava/lang/Object;
    //   398: checkcast android/support/v4/app/BackStackRecord
    //   401: astore #8
    //   403: aload_3
    //   404: aload_1
    //   405: invokevirtual print : (Ljava/lang/String;)V
    //   408: aload_3
    //   409: ldc_w '  #'
    //   412: invokevirtual print : (Ljava/lang/String;)V
    //   415: aload_3
    //   416: iload #5
    //   418: invokevirtual print : (I)V
    //   421: aload_3
    //   422: ldc_w ': '
    //   425: invokevirtual print : (Ljava/lang/String;)V
    //   428: aload_3
    //   429: aload #8
    //   431: invokevirtual toString : ()Ljava/lang/String;
    //   434: invokevirtual println : (Ljava/lang/String;)V
    //   437: aload #8
    //   439: aload #7
    //   441: aload_2
    //   442: aload_3
    //   443: aload #4
    //   445: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   448: iload #5
    //   450: iconst_1
    //   451: iadd
    //   452: istore #5
    //   454: goto -> 382
    //   457: aload_0
    //   458: monitorenter
    //   459: aload_0
    //   460: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   463: ifnull -> 554
    //   466: aload_0
    //   467: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   470: invokevirtual size : ()I
    //   473: istore #6
    //   475: iload #6
    //   477: ifle -> 554
    //   480: aload_3
    //   481: aload_1
    //   482: invokevirtual print : (Ljava/lang/String;)V
    //   485: aload_3
    //   486: ldc_w 'Back Stack Indices:'
    //   489: invokevirtual println : (Ljava/lang/String;)V
    //   492: iconst_0
    //   493: istore #5
    //   495: iload #5
    //   497: iload #6
    //   499: if_icmpge -> 554
    //   502: aload_0
    //   503: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   506: iload #5
    //   508: invokevirtual get : (I)Ljava/lang/Object;
    //   511: checkcast android/support/v4/app/BackStackRecord
    //   514: astore_2
    //   515: aload_3
    //   516: aload_1
    //   517: invokevirtual print : (Ljava/lang/String;)V
    //   520: aload_3
    //   521: ldc_w '  #'
    //   524: invokevirtual print : (Ljava/lang/String;)V
    //   527: aload_3
    //   528: iload #5
    //   530: invokevirtual print : (I)V
    //   533: aload_3
    //   534: ldc_w ': '
    //   537: invokevirtual print : (Ljava/lang/String;)V
    //   540: aload_3
    //   541: aload_2
    //   542: invokevirtual println : (Ljava/lang/Object;)V
    //   545: iload #5
    //   547: iconst_1
    //   548: iadd
    //   549: istore #5
    //   551: goto -> 495
    //   554: aload_0
    //   555: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   558: ifnull -> 597
    //   561: aload_0
    //   562: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   565: invokevirtual size : ()I
    //   568: ifle -> 597
    //   571: aload_3
    //   572: aload_1
    //   573: invokevirtual print : (Ljava/lang/String;)V
    //   576: aload_3
    //   577: ldc_w 'mAvailBackStackIndices: '
    //   580: invokevirtual print : (Ljava/lang/String;)V
    //   583: aload_3
    //   584: aload_0
    //   585: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   588: invokevirtual toArray : ()[Ljava/lang/Object;
    //   591: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   594: invokevirtual println : (Ljava/lang/String;)V
    //   597: aload_0
    //   598: monitorexit
    //   599: aload_0
    //   600: getfield mPendingActions : Ljava/util/ArrayList;
    //   603: ifnull -> 699
    //   606: aload_0
    //   607: getfield mPendingActions : Ljava/util/ArrayList;
    //   610: invokevirtual size : ()I
    //   613: istore #6
    //   615: iload #6
    //   617: ifle -> 699
    //   620: aload_3
    //   621: aload_1
    //   622: invokevirtual print : (Ljava/lang/String;)V
    //   625: aload_3
    //   626: ldc_w 'Pending Actions:'
    //   629: invokevirtual println : (Ljava/lang/String;)V
    //   632: iconst_0
    //   633: istore #5
    //   635: iload #5
    //   637: iload #6
    //   639: if_icmpge -> 699
    //   642: aload_0
    //   643: getfield mPendingActions : Ljava/util/ArrayList;
    //   646: iload #5
    //   648: invokevirtual get : (I)Ljava/lang/Object;
    //   651: checkcast android/support/v4/app/FragmentManagerImpl$OpGenerator
    //   654: astore_2
    //   655: aload_3
    //   656: aload_1
    //   657: invokevirtual print : (Ljava/lang/String;)V
    //   660: aload_3
    //   661: ldc_w '  #'
    //   664: invokevirtual print : (Ljava/lang/String;)V
    //   667: aload_3
    //   668: iload #5
    //   670: invokevirtual print : (I)V
    //   673: aload_3
    //   674: ldc_w ': '
    //   677: invokevirtual print : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_2
    //   682: invokevirtual println : (Ljava/lang/Object;)V
    //   685: iload #5
    //   687: iconst_1
    //   688: iadd
    //   689: istore #5
    //   691: goto -> 635
    //   694: astore_1
    //   695: aload_0
    //   696: monitorexit
    //   697: aload_1
    //   698: athrow
    //   699: aload_3
    //   700: aload_1
    //   701: invokevirtual print : (Ljava/lang/String;)V
    //   704: aload_3
    //   705: ldc_w 'FragmentManager misc state:'
    //   708: invokevirtual println : (Ljava/lang/String;)V
    //   711: aload_3
    //   712: aload_1
    //   713: invokevirtual print : (Ljava/lang/String;)V
    //   716: aload_3
    //   717: ldc_w '  mHost='
    //   720: invokevirtual print : (Ljava/lang/String;)V
    //   723: aload_3
    //   724: aload_0
    //   725: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   728: invokevirtual println : (Ljava/lang/Object;)V
    //   731: aload_3
    //   732: aload_1
    //   733: invokevirtual print : (Ljava/lang/String;)V
    //   736: aload_3
    //   737: ldc_w '  mContainer='
    //   740: invokevirtual print : (Ljava/lang/String;)V
    //   743: aload_3
    //   744: aload_0
    //   745: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   748: invokevirtual println : (Ljava/lang/Object;)V
    //   751: aload_0
    //   752: getfield mParent : Landroid/support/v4/app/Fragment;
    //   755: ifnull -> 778
    //   758: aload_3
    //   759: aload_1
    //   760: invokevirtual print : (Ljava/lang/String;)V
    //   763: aload_3
    //   764: ldc_w '  mParent='
    //   767: invokevirtual print : (Ljava/lang/String;)V
    //   770: aload_3
    //   771: aload_0
    //   772: getfield mParent : Landroid/support/v4/app/Fragment;
    //   775: invokevirtual println : (Ljava/lang/Object;)V
    //   778: aload_3
    //   779: aload_1
    //   780: invokevirtual print : (Ljava/lang/String;)V
    //   783: aload_3
    //   784: ldc_w '  mCurState='
    //   787: invokevirtual print : (Ljava/lang/String;)V
    //   790: aload_3
    //   791: aload_0
    //   792: getfield mCurState : I
    //   795: invokevirtual print : (I)V
    //   798: aload_3
    //   799: ldc_w ' mStateSaved='
    //   802: invokevirtual print : (Ljava/lang/String;)V
    //   805: aload_3
    //   806: aload_0
    //   807: getfield mStateSaved : Z
    //   810: invokevirtual print : (Z)V
    //   813: aload_3
    //   814: ldc_w ' mStopped='
    //   817: invokevirtual print : (Ljava/lang/String;)V
    //   820: aload_3
    //   821: aload_0
    //   822: getfield mStopped : Z
    //   825: invokevirtual print : (Z)V
    //   828: aload_3
    //   829: ldc_w ' mDestroyed='
    //   832: invokevirtual print : (Ljava/lang/String;)V
    //   835: aload_3
    //   836: aload_0
    //   837: getfield mDestroyed : Z
    //   840: invokevirtual println : (Z)V
    //   843: aload_0
    //   844: getfield mNeedMenuInvalidate : Z
    //   847: ifeq -> 870
    //   850: aload_3
    //   851: aload_1
    //   852: invokevirtual print : (Ljava/lang/String;)V
    //   855: aload_3
    //   856: ldc_w '  mNeedMenuInvalidate='
    //   859: invokevirtual print : (Ljava/lang/String;)V
    //   862: aload_3
    //   863: aload_0
    //   864: getfield mNeedMenuInvalidate : Z
    //   867: invokevirtual println : (Z)V
    //   870: aload_0
    //   871: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   874: ifnull -> 897
    //   877: aload_3
    //   878: aload_1
    //   879: invokevirtual print : (Ljava/lang/String;)V
    //   882: aload_3
    //   883: ldc_w '  mNoTransactionsBecause='
    //   886: invokevirtual print : (Ljava/lang/String;)V
    //   889: aload_3
    //   890: aload_0
    //   891: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   894: invokevirtual println : (Ljava/lang/String;)V
    //   897: return
    // Exception table:
    //   from	to	target	type
    //   459	475	694	finally
    //   480	492	694	finally
    //   502	545	694	finally
    //   554	597	694	finally
    //   597	599	694	finally
    //   695	697	694	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 24
    //   17: aload_0
    //   18: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   21: ifnonnull -> 47
    //   24: iload_2
    //   25: ifeq -> 31
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: new java/lang/IllegalStateException
    //   34: dup
    //   35: ldc_w 'Activity has been destroyed'
    //   38: invokespecial <init> : (Ljava/lang/String;)V
    //   41: athrow
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    //   47: aload_0
    //   48: getfield mPendingActions : Ljava/util/ArrayList;
    //   51: ifnonnull -> 65
    //   54: aload_0
    //   55: new java/util/ArrayList
    //   58: dup
    //   59: invokespecial <init> : ()V
    //   62: putfield mPendingActions : Ljava/util/ArrayList;
    //   65: aload_0
    //   66: getfield mPendingActions : Ljava/util/ArrayList;
    //   69: aload_1
    //   70: invokevirtual add : (Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_0
    //   75: invokespecial scheduleCommit : ()V
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    // Exception table:
    //   from	to	target	type
    //   10	24	42	finally
    //   28	30	42	finally
    //   31	42	42	finally
    //   43	45	42	finally
    //   47	65	42	finally
    //   65	80	42	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.mView = paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
    } else {
      return;
    } 
    paramFragment.mInnerView = null;
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
        doPendingDeferredStart();
        return;
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    int i = this.mAdded.size() - 1;
    while (i >= 0) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment == null || fragment.mFragmentId != paramInt) {
        i--;
        continue;
      } 
      return fragment;
    } 
    if (this.mActive != null)
      for (i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          Fragment fragment1 = fragment;
          if (fragment.mFragmentId != paramInt)
            continue; 
          return fragment1;
        } 
        continue;
      }  
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null) {
      int i = this.mAdded.size() - 1;
      while (i >= 0) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment == null || !paramString.equals(fragment.mTag)) {
          i--;
          continue;
        } 
        return fragment;
      } 
    } 
    if (this.mActive != null && paramString != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          Fragment fragment1 = fragment;
          if (!paramString.equals(fragment.mTag))
            continue; 
          return fragment1;
        } 
        continue;
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    if (this.mActive != null && paramString != null)
      for (int i = this.mActive.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          fragment = fragment.findFragmentByWho(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 62
    //   36: ldc 'FragmentManager'
    //   38: new java/lang/StringBuilder
    //   41: dup
    //   42: invokespecial <init> : ()V
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: iload_1
    //   52: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   55: invokevirtual toString : ()Ljava/lang/String;
    //   58: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   61: pop
    //   62: aload_0
    //   63: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   66: iload_1
    //   67: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   70: invokevirtual add : (Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_0
    //   75: monitorexit
    //   76: return
    //   77: astore_2
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_2
    //   81: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	77	finally
    //   30	62	77	finally
    //   62	76	77	finally
    //   78	80	77	finally
  }
  
  int getActiveFragmentCount() {
    return (this.mActive == null) ? 0 : this.mActive.size();
  }
  
  List<Fragment> getActiveFragments() {
    if (this.mActive == null)
      return null; 
    int j = this.mActive.size();
    ArrayList<Object> arrayList = new ArrayList(j);
    int i = 0;
    while (true) {
      ArrayList<Object> arrayList1 = arrayList;
      if (i < j) {
        arrayList.add(this.mActive.valueAt(i));
        i++;
        continue;
      } 
      return arrayList1;
    } 
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    return (this.mBackStack != null) ? this.mBackStack.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    Fragment fragment2 = (Fragment)this.mActive.get(i);
    Fragment fragment1 = fragment2;
    if (fragment2 == null) {
      throwException(new IllegalStateException("Fragment no longer exists for key " + paramString + ": index " + i));
      return fragment2;
    } 
    return fragment1;
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.EMPTY_LIST; 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  public void hideFragment(Fragment paramFragment) {
    boolean bool = true;
    if (DEBUG)
      Log.v("FragmentManager", "hide: " + paramFragment); 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      if (paramFragment.mHiddenChanged)
        bool = false; 
      paramFragment.mHiddenChanged = bool;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool2;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          if (bool)
            throw runtimeException; 
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mHost.onHasWindowAnimations())
            paramInt1 = this.mHost.onGetWindowAnimations(); 
        } 
        return (AnimationOrAnimator)((paramInt1 == 0) ? null : null);
      case 1:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.125F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(this.mHost.getContext(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(this.mHost.getContext(), 0.0F, 1.0F);
      case 6:
        break;
    } 
    return makeFadeAnimation(this.mHost.getContext(), 1.0F, 0.0F);
  }
  
  void makeActive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      int i = this.mNextFragmentIndex;
      this.mNextFragmentIndex = i + 1;
      paramFragment.setIndex(i, this.mParent);
      if (this.mActive == null)
        this.mActive = new SparseArray(); 
      this.mActive.put(paramFragment.mIndex, paramFragment);
      if (DEBUG) {
        Log.v("FragmentManager", "Allocated fragment index " + paramFragment);
        return;
      } 
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (DEBUG)
      Log.v("FragmentManager", "Freeing fragment index " + paramFragment); 
    this.mActive.put(paramFragment.mIndex, null);
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment != null) {
      int j = this.mCurState;
      int i = j;
      if (paramFragment.mRemoving)
        if (paramFragment.isInBackStack()) {
          i = Math.min(j, 1);
        } else {
          i = Math.min(j, 0);
        }  
      moveToState(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
      if (paramFragment.mView != null) {
        Fragment fragment = findFragmentUnder(paramFragment);
        if (fragment != null) {
          View view = fragment.mView;
          ViewGroup viewGroup = paramFragment.mContainer;
          i = viewGroup.indexOfChild(view);
          j = viewGroup.indexOfChild(paramFragment.mView);
          if (j < i) {
            viewGroup.removeViewAt(j);
            viewGroup.addView(paramFragment.mView, i);
          } 
        } 
        if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
          if (paramFragment.mPostponedAlpha > 0.0F)
            paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
          paramFragment.mPostponedAlpha = 0.0F;
          paramFragment.mIsNewlyAdded = false;
          AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
          if (animationOrAnimator != null) {
            setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
            if (animationOrAnimator.animation != null) {
              paramFragment.mView.startAnimation(animationOrAnimator.animation);
            } else {
              animationOrAnimator.animator.setTarget(paramFragment.mView);
              animationOrAnimator.animator.start();
            } 
          } 
        } 
      } 
      if (paramFragment.mHiddenChanged) {
        completeShowHideFragment(paramFragment);
        return;
      } 
    } 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost == null && paramInt != 0)
      throw new IllegalStateException("No activity"); 
    if (paramBoolean || paramInt != this.mCurState) {
      this.mCurState = paramInt;
      if (this.mActive != null) {
        int i = this.mAdded.size();
        for (paramInt = 0; paramInt < i; paramInt++)
          moveFragmentToExpectedState(this.mAdded.get(paramInt)); 
        i = this.mActive.size();
        for (paramInt = 0; paramInt < i; paramInt++) {
          Fragment fragment = (Fragment)this.mActive.valueAt(paramInt);
          if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
            moveFragmentToExpectedState(fragment); 
        } 
        startPendingDeferredFragments();
        if (this.mNeedMenuInvalidate && this.mHost != null && this.mCurState == 5) {
          this.mHost.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
          return;
        } 
      } 
    } 
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: ifeq -> 17
    //   7: iload_2
    //   8: istore #7
    //   10: aload_1
    //   11: getfield mDetached : Z
    //   14: ifeq -> 28
    //   17: iload_2
    //   18: istore #7
    //   20: iload_2
    //   21: iconst_1
    //   22: if_icmple -> 28
    //   25: iconst_1
    //   26: istore #7
    //   28: iload #7
    //   30: istore #6
    //   32: aload_1
    //   33: getfield mRemoving : Z
    //   36: ifeq -> 69
    //   39: iload #7
    //   41: istore #6
    //   43: iload #7
    //   45: aload_1
    //   46: getfield mState : I
    //   49: if_icmple -> 69
    //   52: aload_1
    //   53: getfield mState : I
    //   56: ifne -> 124
    //   59: aload_1
    //   60: invokevirtual isInBackStack : ()Z
    //   63: ifeq -> 124
    //   66: iconst_1
    //   67: istore #6
    //   69: iload #6
    //   71: istore_2
    //   72: aload_1
    //   73: getfield mDeferStart : Z
    //   76: ifeq -> 101
    //   79: iload #6
    //   81: istore_2
    //   82: aload_1
    //   83: getfield mState : I
    //   86: iconst_4
    //   87: if_icmpge -> 101
    //   90: iload #6
    //   92: istore_2
    //   93: iload #6
    //   95: iconst_3
    //   96: if_icmple -> 101
    //   99: iconst_3
    //   100: istore_2
    //   101: aload_1
    //   102: getfield mState : I
    //   105: iload_2
    //   106: if_icmpgt -> 1346
    //   109: aload_1
    //   110: getfield mFromLayout : Z
    //   113: ifeq -> 133
    //   116: aload_1
    //   117: getfield mInLayout : Z
    //   120: ifne -> 133
    //   123: return
    //   124: aload_1
    //   125: getfield mState : I
    //   128: istore #6
    //   130: goto -> 69
    //   133: aload_1
    //   134: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   137: ifnonnull -> 147
    //   140: aload_1
    //   141: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   144: ifnull -> 169
    //   147: aload_1
    //   148: aconst_null
    //   149: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   152: aload_1
    //   153: aconst_null
    //   154: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   157: aload_0
    //   158: aload_1
    //   159: aload_1
    //   160: invokevirtual getStateAfterAnimating : ()I
    //   163: iconst_0
    //   164: iconst_0
    //   165: iconst_1
    //   166: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   169: iload_2
    //   170: istore #4
    //   172: iload_2
    //   173: istore #6
    //   175: iload_2
    //   176: istore #7
    //   178: iload_2
    //   179: istore_3
    //   180: aload_1
    //   181: getfield mState : I
    //   184: tableswitch default -> 220, 0 -> 295, 1 -> 761, 2 -> 1156, 3 -> 1175, 4 -> 1229
    //   220: iload_2
    //   221: istore #6
    //   223: aload_1
    //   224: getfield mState : I
    //   227: iload #6
    //   229: if_icmpeq -> 123
    //   232: ldc 'FragmentManager'
    //   234: new java/lang/StringBuilder
    //   237: dup
    //   238: invokespecial <init> : ()V
    //   241: ldc_w 'moveToState: Fragment state for '
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: aload_1
    //   248: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   251: ldc_w ' not updated inline; '
    //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: ldc_w 'expected state '
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: iload #6
    //   265: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   268: ldc_w ' found '
    //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   274: aload_1
    //   275: getfield mState : I
    //   278: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   281: invokevirtual toString : ()Ljava/lang/String;
    //   284: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   287: pop
    //   288: aload_1
    //   289: iload #6
    //   291: putfield mState : I
    //   294: return
    //   295: iload_2
    //   296: istore #4
    //   298: iload_2
    //   299: ifle -> 761
    //   302: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   305: ifeq -> 334
    //   308: ldc 'FragmentManager'
    //   310: new java/lang/StringBuilder
    //   313: dup
    //   314: invokespecial <init> : ()V
    //   317: ldc_w 'moveto CREATED: '
    //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: aload_1
    //   324: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   327: invokevirtual toString : ()Ljava/lang/String;
    //   330: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   333: pop
    //   334: iload_2
    //   335: istore #4
    //   337: aload_1
    //   338: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   341: ifnull -> 458
    //   344: aload_1
    //   345: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   348: aload_0
    //   349: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   352: invokevirtual getContext : ()Landroid/content/Context;
    //   355: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   358: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   361: aload_1
    //   362: aload_1
    //   363: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   366: ldc 'android:view_state'
    //   368: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   371: putfield mSavedViewState : Landroid/util/SparseArray;
    //   374: aload_1
    //   375: aload_0
    //   376: aload_1
    //   377: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   380: ldc 'android:target_state'
    //   382: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    //   385: putfield mTarget : Landroid/support/v4/app/Fragment;
    //   388: aload_1
    //   389: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   392: ifnull -> 409
    //   395: aload_1
    //   396: aload_1
    //   397: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   400: ldc 'android:target_req_state'
    //   402: iconst_0
    //   403: invokevirtual getInt : (Ljava/lang/String;I)I
    //   406: putfield mTargetRequestCode : I
    //   409: aload_1
    //   410: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   413: ifnull -> 571
    //   416: aload_1
    //   417: aload_1
    //   418: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   421: invokevirtual booleanValue : ()Z
    //   424: putfield mUserVisibleHint : Z
    //   427: aload_1
    //   428: aconst_null
    //   429: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   432: iload_2
    //   433: istore #4
    //   435: aload_1
    //   436: getfield mUserVisibleHint : Z
    //   439: ifne -> 458
    //   442: aload_1
    //   443: iconst_1
    //   444: putfield mDeferStart : Z
    //   447: iload_2
    //   448: istore #4
    //   450: iload_2
    //   451: iconst_3
    //   452: if_icmple -> 458
    //   455: iconst_3
    //   456: istore #4
    //   458: aload_1
    //   459: aload_0
    //   460: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   463: putfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   466: aload_1
    //   467: aload_0
    //   468: getfield mParent : Landroid/support/v4/app/Fragment;
    //   471: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   474: aload_0
    //   475: getfield mParent : Landroid/support/v4/app/Fragment;
    //   478: ifnull -> 588
    //   481: aload_0
    //   482: getfield mParent : Landroid/support/v4/app/Fragment;
    //   485: getfield mChildFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   488: astore #8
    //   490: aload_1
    //   491: aload #8
    //   493: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   496: aload_1
    //   497: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   500: ifnull -> 623
    //   503: aload_0
    //   504: getfield mActive : Landroid/util/SparseArray;
    //   507: aload_1
    //   508: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   511: getfield mIndex : I
    //   514: invokevirtual get : (I)Ljava/lang/Object;
    //   517: aload_1
    //   518: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   521: if_acmpeq -> 600
    //   524: new java/lang/IllegalStateException
    //   527: dup
    //   528: new java/lang/StringBuilder
    //   531: dup
    //   532: invokespecial <init> : ()V
    //   535: ldc_w 'Fragment '
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: aload_1
    //   542: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   545: ldc_w ' declared target fragment '
    //   548: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   551: aload_1
    //   552: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   555: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   558: ldc_w ' that does not belong to this FragmentManager!'
    //   561: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: invokevirtual toString : ()Ljava/lang/String;
    //   567: invokespecial <init> : (Ljava/lang/String;)V
    //   570: athrow
    //   571: aload_1
    //   572: aload_1
    //   573: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   576: ldc 'android:user_visible_hint'
    //   578: iconst_1
    //   579: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   582: putfield mUserVisibleHint : Z
    //   585: goto -> 432
    //   588: aload_0
    //   589: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   592: invokevirtual getFragmentManagerImpl : ()Landroid/support/v4/app/FragmentManagerImpl;
    //   595: astore #8
    //   597: goto -> 490
    //   600: aload_1
    //   601: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   604: getfield mState : I
    //   607: iconst_1
    //   608: if_icmpge -> 623
    //   611: aload_0
    //   612: aload_1
    //   613: getfield mTarget : Landroid/support/v4/app/Fragment;
    //   616: iconst_1
    //   617: iconst_0
    //   618: iconst_0
    //   619: iconst_1
    //   620: invokevirtual moveToState : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   623: aload_0
    //   624: aload_1
    //   625: aload_0
    //   626: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   629: invokevirtual getContext : ()Landroid/content/Context;
    //   632: iconst_0
    //   633: invokevirtual dispatchOnFragmentPreAttached : (Landroid/support/v4/app/Fragment;Landroid/content/Context;Z)V
    //   636: aload_1
    //   637: iconst_0
    //   638: putfield mCalled : Z
    //   641: aload_1
    //   642: aload_0
    //   643: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   646: invokevirtual getContext : ()Landroid/content/Context;
    //   649: invokevirtual onAttach : (Landroid/content/Context;)V
    //   652: aload_1
    //   653: getfield mCalled : Z
    //   656: ifne -> 693
    //   659: new android/support/v4/app/SuperNotCalledException
    //   662: dup
    //   663: new java/lang/StringBuilder
    //   666: dup
    //   667: invokespecial <init> : ()V
    //   670: ldc_w 'Fragment '
    //   673: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   676: aload_1
    //   677: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   680: ldc_w ' did not call through to super.onAttach()'
    //   683: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: invokevirtual toString : ()Ljava/lang/String;
    //   689: invokespecial <init> : (Ljava/lang/String;)V
    //   692: athrow
    //   693: aload_1
    //   694: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   697: ifnonnull -> 1295
    //   700: aload_0
    //   701: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   704: aload_1
    //   705: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   708: aload_0
    //   709: aload_1
    //   710: aload_0
    //   711: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   714: invokevirtual getContext : ()Landroid/content/Context;
    //   717: iconst_0
    //   718: invokevirtual dispatchOnFragmentAttached : (Landroid/support/v4/app/Fragment;Landroid/content/Context;Z)V
    //   721: aload_1
    //   722: getfield mIsCreated : Z
    //   725: ifne -> 1306
    //   728: aload_0
    //   729: aload_1
    //   730: aload_1
    //   731: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   734: iconst_0
    //   735: invokevirtual dispatchOnFragmentPreCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   738: aload_1
    //   739: aload_1
    //   740: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   743: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   746: aload_0
    //   747: aload_1
    //   748: aload_1
    //   749: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   752: iconst_0
    //   753: invokevirtual dispatchOnFragmentCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   756: aload_1
    //   757: iconst_0
    //   758: putfield mRetaining : Z
    //   761: aload_0
    //   762: aload_1
    //   763: invokevirtual ensureInflatedFragmentView : (Landroid/support/v4/app/Fragment;)V
    //   766: iload #4
    //   768: istore #6
    //   770: iload #4
    //   772: iconst_1
    //   773: if_icmple -> 1156
    //   776: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   779: ifeq -> 808
    //   782: ldc 'FragmentManager'
    //   784: new java/lang/StringBuilder
    //   787: dup
    //   788: invokespecial <init> : ()V
    //   791: ldc_w 'moveto ACTIVITY_CREATED: '
    //   794: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   797: aload_1
    //   798: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   801: invokevirtual toString : ()Ljava/lang/String;
    //   804: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   807: pop
    //   808: aload_1
    //   809: getfield mFromLayout : Z
    //   812: ifne -> 1114
    //   815: aconst_null
    //   816: astore #8
    //   818: aload_1
    //   819: getfield mContainerId : I
    //   822: ifeq -> 981
    //   825: aload_1
    //   826: getfield mContainerId : I
    //   829: iconst_m1
    //   830: if_icmpne -> 870
    //   833: aload_0
    //   834: new java/lang/IllegalArgumentException
    //   837: dup
    //   838: new java/lang/StringBuilder
    //   841: dup
    //   842: invokespecial <init> : ()V
    //   845: ldc_w 'Cannot create fragment '
    //   848: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   851: aload_1
    //   852: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   855: ldc_w ' for a container view with no id'
    //   858: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   861: invokevirtual toString : ()Ljava/lang/String;
    //   864: invokespecial <init> : (Ljava/lang/String;)V
    //   867: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   870: aload_0
    //   871: getfield mContainer : Landroid/support/v4/app/FragmentContainer;
    //   874: aload_1
    //   875: getfield mContainerId : I
    //   878: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   881: checkcast android/view/ViewGroup
    //   884: astore #9
    //   886: aload #9
    //   888: astore #8
    //   890: aload #9
    //   892: ifnonnull -> 981
    //   895: aload #9
    //   897: astore #8
    //   899: aload_1
    //   900: getfield mRestored : Z
    //   903: ifne -> 981
    //   906: aload_1
    //   907: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   910: aload_1
    //   911: getfield mContainerId : I
    //   914: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   917: astore #8
    //   919: aload_0
    //   920: new java/lang/IllegalArgumentException
    //   923: dup
    //   924: new java/lang/StringBuilder
    //   927: dup
    //   928: invokespecial <init> : ()V
    //   931: ldc_w 'No view found for id 0x'
    //   934: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   937: aload_1
    //   938: getfield mContainerId : I
    //   941: invokestatic toHexString : (I)Ljava/lang/String;
    //   944: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   947: ldc_w ' ('
    //   950: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   953: aload #8
    //   955: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   958: ldc_w ') for fragment '
    //   961: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   964: aload_1
    //   965: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   968: invokevirtual toString : ()Ljava/lang/String;
    //   971: invokespecial <init> : (Ljava/lang/String;)V
    //   974: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   977: aload #9
    //   979: astore #8
    //   981: aload_1
    //   982: aload #8
    //   984: putfield mContainer : Landroid/view/ViewGroup;
    //   987: aload_1
    //   988: aload_1
    //   989: aload_1
    //   990: aload_1
    //   991: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   994: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   997: aload #8
    //   999: aload_1
    //   1000: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1003: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    //   1006: putfield mView : Landroid/view/View;
    //   1009: aload_1
    //   1010: getfield mView : Landroid/view/View;
    //   1013: ifnull -> 1338
    //   1016: aload_1
    //   1017: aload_1
    //   1018: getfield mView : Landroid/view/View;
    //   1021: putfield mInnerView : Landroid/view/View;
    //   1024: aload_1
    //   1025: getfield mView : Landroid/view/View;
    //   1028: iconst_0
    //   1029: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1032: aload #8
    //   1034: ifnull -> 1046
    //   1037: aload #8
    //   1039: aload_1
    //   1040: getfield mView : Landroid/view/View;
    //   1043: invokevirtual addView : (Landroid/view/View;)V
    //   1046: aload_1
    //   1047: getfield mHidden : Z
    //   1050: ifeq -> 1062
    //   1053: aload_1
    //   1054: getfield mView : Landroid/view/View;
    //   1057: bipush #8
    //   1059: invokevirtual setVisibility : (I)V
    //   1062: aload_1
    //   1063: aload_1
    //   1064: getfield mView : Landroid/view/View;
    //   1067: aload_1
    //   1068: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1071: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1074: aload_0
    //   1075: aload_1
    //   1076: aload_1
    //   1077: getfield mView : Landroid/view/View;
    //   1080: aload_1
    //   1081: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1084: iconst_0
    //   1085: invokevirtual dispatchOnFragmentViewCreated : (Landroid/support/v4/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1088: aload_1
    //   1089: getfield mView : Landroid/view/View;
    //   1092: invokevirtual getVisibility : ()I
    //   1095: ifne -> 1332
    //   1098: aload_1
    //   1099: getfield mContainer : Landroid/view/ViewGroup;
    //   1102: ifnull -> 1332
    //   1105: iconst_1
    //   1106: istore #5
    //   1108: aload_1
    //   1109: iload #5
    //   1111: putfield mIsNewlyAdded : Z
    //   1114: aload_1
    //   1115: aload_1
    //   1116: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1119: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1122: aload_0
    //   1123: aload_1
    //   1124: aload_1
    //   1125: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1128: iconst_0
    //   1129: invokevirtual dispatchOnFragmentActivityCreated : (Landroid/support/v4/app/Fragment;Landroid/os/Bundle;Z)V
    //   1132: aload_1
    //   1133: getfield mView : Landroid/view/View;
    //   1136: ifnull -> 1147
    //   1139: aload_1
    //   1140: aload_1
    //   1141: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1144: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1147: aload_1
    //   1148: aconst_null
    //   1149: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1152: iload #4
    //   1154: istore #6
    //   1156: iload #6
    //   1158: istore #7
    //   1160: iload #6
    //   1162: iconst_2
    //   1163: if_icmple -> 1175
    //   1166: aload_1
    //   1167: iconst_3
    //   1168: putfield mState : I
    //   1171: iload #6
    //   1173: istore #7
    //   1175: iload #7
    //   1177: istore_3
    //   1178: iload #7
    //   1180: iconst_3
    //   1181: if_icmple -> 1229
    //   1184: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1187: ifeq -> 1216
    //   1190: ldc 'FragmentManager'
    //   1192: new java/lang/StringBuilder
    //   1195: dup
    //   1196: invokespecial <init> : ()V
    //   1199: ldc_w 'moveto STARTED: '
    //   1202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1205: aload_1
    //   1206: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1209: invokevirtual toString : ()Ljava/lang/String;
    //   1212: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1215: pop
    //   1216: aload_1
    //   1217: invokevirtual performStart : ()V
    //   1220: aload_0
    //   1221: aload_1
    //   1222: iconst_0
    //   1223: invokevirtual dispatchOnFragmentStarted : (Landroid/support/v4/app/Fragment;Z)V
    //   1226: iload #7
    //   1228: istore_3
    //   1229: iload_3
    //   1230: istore #6
    //   1232: iload_3
    //   1233: iconst_4
    //   1234: if_icmple -> 223
    //   1237: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1240: ifeq -> 1269
    //   1243: ldc 'FragmentManager'
    //   1245: new java/lang/StringBuilder
    //   1248: dup
    //   1249: invokespecial <init> : ()V
    //   1252: ldc_w 'moveto RESUMED: '
    //   1255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1258: aload_1
    //   1259: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1262: invokevirtual toString : ()Ljava/lang/String;
    //   1265: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1268: pop
    //   1269: aload_1
    //   1270: invokevirtual performResume : ()V
    //   1273: aload_0
    //   1274: aload_1
    //   1275: iconst_0
    //   1276: invokevirtual dispatchOnFragmentResumed : (Landroid/support/v4/app/Fragment;Z)V
    //   1279: aload_1
    //   1280: aconst_null
    //   1281: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1284: aload_1
    //   1285: aconst_null
    //   1286: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1289: iload_3
    //   1290: istore #6
    //   1292: goto -> 223
    //   1295: aload_1
    //   1296: getfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   1299: aload_1
    //   1300: invokevirtual onAttachFragment : (Landroid/support/v4/app/Fragment;)V
    //   1303: goto -> 708
    //   1306: aload_1
    //   1307: aload_1
    //   1308: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1311: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   1314: aload_1
    //   1315: iconst_1
    //   1316: putfield mState : I
    //   1319: goto -> 756
    //   1322: astore #8
    //   1324: ldc_w 'unknown'
    //   1327: astore #8
    //   1329: goto -> 919
    //   1332: iconst_0
    //   1333: istore #5
    //   1335: goto -> 1108
    //   1338: aload_1
    //   1339: aconst_null
    //   1340: putfield mInnerView : Landroid/view/View;
    //   1343: goto -> 1114
    //   1346: iload_2
    //   1347: istore #6
    //   1349: aload_1
    //   1350: getfield mState : I
    //   1353: iload_2
    //   1354: if_icmple -> 223
    //   1357: aload_1
    //   1358: getfield mState : I
    //   1361: tableswitch default -> 1396, 1 -> 1402, 2 -> 1600, 3 -> 1559, 4 -> 1512, 5 -> 1465
    //   1396: iload_2
    //   1397: istore #6
    //   1399: goto -> 223
    //   1402: iload_2
    //   1403: istore #6
    //   1405: iload_2
    //   1406: iconst_1
    //   1407: if_icmpge -> 223
    //   1410: aload_0
    //   1411: getfield mDestroyed : Z
    //   1414: ifeq -> 1440
    //   1417: aload_1
    //   1418: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1421: ifnull -> 1824
    //   1424: aload_1
    //   1425: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1428: astore #8
    //   1430: aload_1
    //   1431: aconst_null
    //   1432: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1435: aload #8
    //   1437: invokevirtual clearAnimation : ()V
    //   1440: aload_1
    //   1441: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1444: ifnonnull -> 1454
    //   1447: aload_1
    //   1448: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1451: ifnull -> 1850
    //   1454: aload_1
    //   1455: iload_2
    //   1456: invokevirtual setStateAfterAnimating : (I)V
    //   1459: iconst_1
    //   1460: istore #6
    //   1462: goto -> 223
    //   1465: iload_2
    //   1466: iconst_5
    //   1467: if_icmpge -> 1512
    //   1470: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1473: ifeq -> 1502
    //   1476: ldc 'FragmentManager'
    //   1478: new java/lang/StringBuilder
    //   1481: dup
    //   1482: invokespecial <init> : ()V
    //   1485: ldc_w 'movefrom RESUMED: '
    //   1488: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1491: aload_1
    //   1492: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1495: invokevirtual toString : ()Ljava/lang/String;
    //   1498: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1501: pop
    //   1502: aload_1
    //   1503: invokevirtual performPause : ()V
    //   1506: aload_0
    //   1507: aload_1
    //   1508: iconst_0
    //   1509: invokevirtual dispatchOnFragmentPaused : (Landroid/support/v4/app/Fragment;Z)V
    //   1512: iload_2
    //   1513: iconst_4
    //   1514: if_icmpge -> 1559
    //   1517: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1520: ifeq -> 1549
    //   1523: ldc 'FragmentManager'
    //   1525: new java/lang/StringBuilder
    //   1528: dup
    //   1529: invokespecial <init> : ()V
    //   1532: ldc_w 'movefrom STARTED: '
    //   1535: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1538: aload_1
    //   1539: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1542: invokevirtual toString : ()Ljava/lang/String;
    //   1545: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1548: pop
    //   1549: aload_1
    //   1550: invokevirtual performStop : ()V
    //   1553: aload_0
    //   1554: aload_1
    //   1555: iconst_0
    //   1556: invokevirtual dispatchOnFragmentStopped : (Landroid/support/v4/app/Fragment;Z)V
    //   1559: iload_2
    //   1560: iconst_3
    //   1561: if_icmpge -> 1600
    //   1564: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1567: ifeq -> 1596
    //   1570: ldc 'FragmentManager'
    //   1572: new java/lang/StringBuilder
    //   1575: dup
    //   1576: invokespecial <init> : ()V
    //   1579: ldc_w 'movefrom STOPPED: '
    //   1582: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1585: aload_1
    //   1586: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1589: invokevirtual toString : ()Ljava/lang/String;
    //   1592: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1595: pop
    //   1596: aload_1
    //   1597: invokevirtual performReallyStop : ()V
    //   1600: iload_2
    //   1601: iconst_2
    //   1602: if_icmpge -> 1402
    //   1605: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1608: ifeq -> 1637
    //   1611: ldc 'FragmentManager'
    //   1613: new java/lang/StringBuilder
    //   1616: dup
    //   1617: invokespecial <init> : ()V
    //   1620: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1623: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1626: aload_1
    //   1627: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1630: invokevirtual toString : ()Ljava/lang/String;
    //   1633: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1636: pop
    //   1637: aload_1
    //   1638: getfield mView : Landroid/view/View;
    //   1641: ifnull -> 1667
    //   1644: aload_0
    //   1645: getfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   1648: aload_1
    //   1649: invokevirtual onShouldSaveFragmentState : (Landroid/support/v4/app/Fragment;)Z
    //   1652: ifeq -> 1667
    //   1655: aload_1
    //   1656: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1659: ifnonnull -> 1667
    //   1662: aload_0
    //   1663: aload_1
    //   1664: invokevirtual saveFragmentViewState : (Landroid/support/v4/app/Fragment;)V
    //   1667: aload_1
    //   1668: invokevirtual performDestroyView : ()V
    //   1671: aload_0
    //   1672: aload_1
    //   1673: iconst_0
    //   1674: invokevirtual dispatchOnFragmentViewDestroyed : (Landroid/support/v4/app/Fragment;Z)V
    //   1677: aload_1
    //   1678: getfield mView : Landroid/view/View;
    //   1681: ifnull -> 1801
    //   1684: aload_1
    //   1685: getfield mContainer : Landroid/view/ViewGroup;
    //   1688: ifnull -> 1801
    //   1691: aload_1
    //   1692: getfield mContainer : Landroid/view/ViewGroup;
    //   1695: aload_1
    //   1696: getfield mView : Landroid/view/View;
    //   1699: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1702: aload_1
    //   1703: getfield mView : Landroid/view/View;
    //   1706: invokevirtual clearAnimation : ()V
    //   1709: aconst_null
    //   1710: astore #9
    //   1712: aload #9
    //   1714: astore #8
    //   1716: aload_0
    //   1717: getfield mCurState : I
    //   1720: ifle -> 1772
    //   1723: aload #9
    //   1725: astore #8
    //   1727: aload_0
    //   1728: getfield mDestroyed : Z
    //   1731: ifne -> 1772
    //   1734: aload #9
    //   1736: astore #8
    //   1738: aload_1
    //   1739: getfield mView : Landroid/view/View;
    //   1742: invokevirtual getVisibility : ()I
    //   1745: ifne -> 1772
    //   1748: aload #9
    //   1750: astore #8
    //   1752: aload_1
    //   1753: getfield mPostponedAlpha : F
    //   1756: fconst_0
    //   1757: fcmpl
    //   1758: iflt -> 1772
    //   1761: aload_0
    //   1762: aload_1
    //   1763: iload_3
    //   1764: iconst_0
    //   1765: iload #4
    //   1767: invokevirtual loadAnimation : (Landroid/support/v4/app/Fragment;IZI)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1770: astore #8
    //   1772: aload_1
    //   1773: fconst_0
    //   1774: putfield mPostponedAlpha : F
    //   1777: aload #8
    //   1779: ifnull -> 1790
    //   1782: aload_0
    //   1783: aload_1
    //   1784: aload #8
    //   1786: iload_2
    //   1787: invokespecial animateRemoveFragment : (Landroid/support/v4/app/Fragment;Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1790: aload_1
    //   1791: getfield mContainer : Landroid/view/ViewGroup;
    //   1794: aload_1
    //   1795: getfield mView : Landroid/view/View;
    //   1798: invokevirtual removeView : (Landroid/view/View;)V
    //   1801: aload_1
    //   1802: aconst_null
    //   1803: putfield mContainer : Landroid/view/ViewGroup;
    //   1806: aload_1
    //   1807: aconst_null
    //   1808: putfield mView : Landroid/view/View;
    //   1811: aload_1
    //   1812: aconst_null
    //   1813: putfield mInnerView : Landroid/view/View;
    //   1816: aload_1
    //   1817: iconst_0
    //   1818: putfield mInLayout : Z
    //   1821: goto -> 1402
    //   1824: aload_1
    //   1825: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1828: ifnull -> 1440
    //   1831: aload_1
    //   1832: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1835: astore #8
    //   1837: aload_1
    //   1838: aconst_null
    //   1839: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1842: aload #8
    //   1844: invokevirtual cancel : ()V
    //   1847: goto -> 1440
    //   1850: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   1853: ifeq -> 1882
    //   1856: ldc 'FragmentManager'
    //   1858: new java/lang/StringBuilder
    //   1861: dup
    //   1862: invokespecial <init> : ()V
    //   1865: ldc_w 'movefrom CREATED: '
    //   1868: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1871: aload_1
    //   1872: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1875: invokevirtual toString : ()Ljava/lang/String;
    //   1878: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1881: pop
    //   1882: aload_1
    //   1883: getfield mRetaining : Z
    //   1886: ifne -> 1935
    //   1889: aload_1
    //   1890: invokevirtual performDestroy : ()V
    //   1893: aload_0
    //   1894: aload_1
    //   1895: iconst_0
    //   1896: invokevirtual dispatchOnFragmentDestroyed : (Landroid/support/v4/app/Fragment;Z)V
    //   1899: aload_1
    //   1900: invokevirtual performDetach : ()V
    //   1903: aload_0
    //   1904: aload_1
    //   1905: iconst_0
    //   1906: invokevirtual dispatchOnFragmentDetached : (Landroid/support/v4/app/Fragment;Z)V
    //   1909: iload_2
    //   1910: istore #6
    //   1912: iload #5
    //   1914: ifne -> 223
    //   1917: aload_1
    //   1918: getfield mRetaining : Z
    //   1921: ifne -> 1943
    //   1924: aload_0
    //   1925: aload_1
    //   1926: invokevirtual makeInactive : (Landroid/support/v4/app/Fragment;)V
    //   1929: iload_2
    //   1930: istore #6
    //   1932: goto -> 223
    //   1935: aload_1
    //   1936: iconst_0
    //   1937: putfield mState : I
    //   1940: goto -> 1899
    //   1943: aload_1
    //   1944: aconst_null
    //   1945: putfield mHost : Landroid/support/v4/app/FragmentHostCallback;
    //   1948: aload_1
    //   1949: aconst_null
    //   1950: putfield mParentFragment : Landroid/support/v4/app/Fragment;
    //   1953: aload_1
    //   1954: aconst_null
    //   1955: putfield mFragmentManager : Landroid/support/v4/app/FragmentManagerImpl;
    //   1958: iload_2
    //   1959: istore #6
    //   1961: goto -> 223
    // Exception table:
    //   from	to	target	type
    //   906	919	1322	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    this.mSavedNonConfig = null;
    this.mStateSaved = false;
    this.mStopped = false;
    int j = this.mAdded.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    Fragment fragment1;
    boolean bool;
    if (!"fragment".equals(paramString))
      return null; 
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    String str2 = paramString;
    if (paramString == null)
      str2 = typedArray.getString(0); 
    int i = typedArray.getResourceId(1, -1);
    String str3 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass(this.mHost.getContext(), str2))
      return null; 
    if (paramView != null) {
      bool = paramView.getId();
    } else {
      bool = false;
    } 
    if (bool == -1 && i == -1 && str3 == null)
      throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str2); 
    if (i != -1) {
      Fragment fragment = findFragmentById(i);
    } else {
      paramString = null;
    } 
    String str1 = paramString;
    if (paramString == null) {
      str1 = paramString;
      if (str3 != null)
        fragment1 = findFragmentByTag(str3); 
    } 
    Fragment fragment2 = fragment1;
    if (fragment1 == null) {
      fragment2 = fragment1;
      if (bool != -1)
        fragment2 = findFragmentById(bool); 
    } 
    if (DEBUG)
      Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(i) + " fname=" + str2 + " existing=" + fragment2); 
    if (fragment2 == null) {
      boolean bool1;
      fragment1 = this.mContainer.instantiate(paramContext, str2, null);
      fragment1.mFromLayout = true;
      if (i != 0) {
        bool1 = i;
      } else {
        bool1 = bool;
      } 
      fragment1.mFragmentId = bool1;
      fragment1.mContainerId = bool;
      fragment1.mTag = str3;
      fragment1.mInLayout = true;
      fragment1.mFragmentManager = this;
      fragment1.mHost = this.mHost;
      fragment1.onInflate(this.mHost.getContext(), paramAttributeSet, fragment1.mSavedFragmentState);
      addFragment(fragment1, true);
    } else {
      if (fragment2.mInLayout)
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(i) + ", tag " + str3 + ", or parent id 0x" + Integer.toHexString(bool) + " with another fragment for " + str2); 
      fragment2.mInLayout = true;
      fragment2.mHost = this.mHost;
      fragment1 = fragment2;
      if (!fragment2.mRetaining) {
        fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
        fragment1 = fragment2;
      } 
    } 
    if (this.mCurState < 1 && fragment1.mFromLayout) {
      moveToState(fragment1, 1, 0, 0, false);
    } else {
      moveToState(fragment1);
    } 
    if (fragment1.mView == null)
      throw new IllegalStateException("Fragment " + str2 + " did not create a view."); 
    if (i != 0)
      fragment1.mView.setId(i); 
    if (fragment1.mView.getTag() == null)
      fragment1.mView.setTag(str3); 
    return fragment1.mView;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
    } else {
      return;
    } 
    paramFragment.mDeferStart = false;
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Bad id: " + paramInt1); 
    enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Bad id: " + paramInt1); 
    return popBackStackImmediate(null, paramInt1, paramInt2);
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_3
    //   10: ifnonnull -> 66
    //   13: iload #4
    //   15: ifge -> 66
    //   18: iload #5
    //   20: iconst_1
    //   21: iand
    //   22: ifne -> 66
    //   25: aload_0
    //   26: getfield mBackStack : Ljava/util/ArrayList;
    //   29: invokevirtual size : ()I
    //   32: iconst_1
    //   33: isub
    //   34: istore #4
    //   36: iload #4
    //   38: iflt -> 7
    //   41: aload_1
    //   42: aload_0
    //   43: getfield mBackStack : Ljava/util/ArrayList;
    //   46: iload #4
    //   48: invokevirtual remove : (I)Ljava/lang/Object;
    //   51: invokevirtual add : (Ljava/lang/Object;)Z
    //   54: pop
    //   55: aload_2
    //   56: iconst_1
    //   57: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   60: invokevirtual add : (Ljava/lang/Object;)Z
    //   63: pop
    //   64: iconst_1
    //   65: ireturn
    //   66: iconst_m1
    //   67: istore #6
    //   69: aload_3
    //   70: ifnonnull -> 78
    //   73: iload #4
    //   75: iflt -> 241
    //   78: aload_0
    //   79: getfield mBackStack : Ljava/util/ArrayList;
    //   82: invokevirtual size : ()I
    //   85: iconst_1
    //   86: isub
    //   87: istore #7
    //   89: iload #7
    //   91: iflt -> 124
    //   94: aload_0
    //   95: getfield mBackStack : Ljava/util/ArrayList;
    //   98: iload #7
    //   100: invokevirtual get : (I)Ljava/lang/Object;
    //   103: checkcast android/support/v4/app/BackStackRecord
    //   106: astore #8
    //   108: aload_3
    //   109: ifnull -> 217
    //   112: aload_3
    //   113: aload #8
    //   115: invokevirtual getName : ()Ljava/lang/String;
    //   118: invokevirtual equals : (Ljava/lang/Object;)Z
    //   121: ifeq -> 217
    //   124: iload #7
    //   126: iflt -> 7
    //   129: iload #7
    //   131: istore #6
    //   133: iload #5
    //   135: iconst_1
    //   136: iand
    //   137: ifeq -> 241
    //   140: iload #7
    //   142: iconst_1
    //   143: isub
    //   144: istore #5
    //   146: iload #5
    //   148: istore #6
    //   150: iload #5
    //   152: iflt -> 241
    //   155: aload_0
    //   156: getfield mBackStack : Ljava/util/ArrayList;
    //   159: iload #5
    //   161: invokevirtual get : (I)Ljava/lang/Object;
    //   164: checkcast android/support/v4/app/BackStackRecord
    //   167: astore #8
    //   169: aload_3
    //   170: ifnull -> 185
    //   173: aload_3
    //   174: aload #8
    //   176: invokevirtual getName : ()Ljava/lang/String;
    //   179: invokevirtual equals : (Ljava/lang/Object;)Z
    //   182: ifne -> 208
    //   185: iload #5
    //   187: istore #6
    //   189: iload #4
    //   191: iflt -> 241
    //   194: iload #5
    //   196: istore #6
    //   198: iload #4
    //   200: aload #8
    //   202: getfield mIndex : I
    //   205: if_icmpne -> 241
    //   208: iload #5
    //   210: iconst_1
    //   211: isub
    //   212: istore #5
    //   214: goto -> 146
    //   217: iload #4
    //   219: iflt -> 232
    //   222: iload #4
    //   224: aload #8
    //   226: getfield mIndex : I
    //   229: if_icmpeq -> 124
    //   232: iload #7
    //   234: iconst_1
    //   235: isub
    //   236: istore #7
    //   238: goto -> 89
    //   241: iload #6
    //   243: aload_0
    //   244: getfield mBackStack : Ljava/util/ArrayList;
    //   247: invokevirtual size : ()I
    //   250: iconst_1
    //   251: isub
    //   252: if_icmpeq -> 7
    //   255: aload_0
    //   256: getfield mBackStack : Ljava/util/ArrayList;
    //   259: invokevirtual size : ()I
    //   262: iconst_1
    //   263: isub
    //   264: istore #4
    //   266: iload #4
    //   268: iload #6
    //   270: if_icmple -> 64
    //   273: aload_1
    //   274: aload_0
    //   275: getfield mBackStack : Ljava/util/ArrayList;
    //   278: iload #4
    //   280: invokevirtual remove : (I)Ljava/lang/Object;
    //   283: invokevirtual add : (Ljava/lang/Object;)Z
    //   286: pop
    //   287: aload_2
    //   288: iconst_1
    //   289: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   292: invokevirtual add : (Ljava/lang/Object;)Z
    //   295: pop
    //   296: iload #4
    //   298: iconst_1
    //   299: isub
    //   300: istore #4
    //   302: goto -> 266
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new Pair(paramFragmentLifecycleCallbacks, Boolean.valueOf(paramBoolean)));
  }
  
  public void removeFragment(Fragment paramFragment) {
    boolean bool;
    if (DEBUG)
      Log.v("FragmentManager", "remove: " + paramFragment + " nesting=" + paramFragment.mBackStackNesting); 
    if (!paramFragment.isInBackStack()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!paramFragment.mDetached || bool)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners != null)
      this.mBackStackChangeListeners.remove(paramOnBackStackChangedListener); 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramParcelable != null) {
      FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
      if (fragmentManagerState.mActive != null) {
        Fragment fragment;
        FragmentState fragmentState;
        paramParcelable = null;
        List<ViewModelStore> list = null;
        if (paramFragmentManagerNonConfig != null) {
          byte b;
          List<Fragment> list3 = paramFragmentManagerNonConfig.getFragments();
          List<FragmentManagerNonConfig> list1 = paramFragmentManagerNonConfig.getChildNonConfigs();
          List<ViewModelStore> list2 = paramFragmentManagerNonConfig.getViewModelStores();
          if (list3 != null) {
            b = list3.size();
          } else {
            b = 0;
          } 
          int j = 0;
          while (true) {
            List<FragmentManagerNonConfig> list4 = list1;
            list = list2;
            if (j < b) {
              fragment = list3.get(j);
              if (DEBUG)
                Log.v("FragmentManager", "restoreAllState: re-attaching retained " + fragment); 
              int k;
              for (k = 0; k < fragmentManagerState.mActive.length && (fragmentManagerState.mActive[k]).mIndex != fragment.mIndex; k++);
              if (k == fragmentManagerState.mActive.length)
                throwException(new IllegalStateException("Could not find active fragment with index " + fragment.mIndex)); 
              fragmentState = fragmentManagerState.mActive[k];
              fragmentState.mInstance = fragment;
              fragment.mSavedViewState = null;
              fragment.mBackStackNesting = 0;
              fragment.mInLayout = false;
              fragment.mAdded = false;
              fragment.mTarget = null;
              if (fragmentState.mSavedFragmentState != null) {
                fragmentState.mSavedFragmentState.setClassLoader(this.mHost.getContext().getClassLoader());
                fragment.mSavedViewState = fragmentState.mSavedFragmentState.getSparseParcelableArray("android:view_state");
                fragment.mSavedFragmentState = fragmentState.mSavedFragmentState;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        this.mActive = new SparseArray(fragmentManagerState.mActive.length);
        int i;
        for (i = 0; i < fragmentManagerState.mActive.length; i++) {
          FragmentState fragmentState1 = fragmentManagerState.mActive[i];
          if (fragmentState1 != null) {
            ViewModelStore viewModelStore;
            FragmentManagerNonConfig fragmentManagerNonConfig2 = null;
            FragmentManagerNonConfig fragmentManagerNonConfig1 = fragmentManagerNonConfig2;
            if (fragment != null) {
              fragmentManagerNonConfig1 = fragmentManagerNonConfig2;
              if (i < fragment.size())
                fragmentManagerNonConfig1 = fragment.get(i); 
            } 
            FragmentManagerNonConfig fragmentManagerNonConfig3 = null;
            fragmentManagerNonConfig2 = fragmentManagerNonConfig3;
            if (fragmentState != null) {
              fragmentManagerNonConfig2 = fragmentManagerNonConfig3;
              if (i < fragmentState.size())
                viewModelStore = fragmentState.get(i); 
            } 
            Fragment fragment1 = fragmentState1.instantiate(this.mHost, this.mContainer, this.mParent, fragmentManagerNonConfig1, viewModelStore);
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: active #" + i + ": " + fragment1); 
            this.mActive.put(fragment1.mIndex, fragment1);
            fragmentState1.mInstance = null;
          } 
        } 
        if (paramFragmentManagerNonConfig != null) {
          List<Fragment> list1 = paramFragmentManagerNonConfig.getFragments();
          if (list1 != null) {
            i = list1.size();
          } else {
            i = 0;
          } 
          int j;
          for (j = 0; j < i; j++) {
            Fragment fragment1 = list1.get(j);
            if (fragment1.mTargetIndex >= 0) {
              fragment1.mTarget = (Fragment)this.mActive.get(fragment1.mTargetIndex);
              if (fragment1.mTarget == null)
                Log.w("FragmentManager", "Re-attaching retained fragment " + fragment1 + " target no longer exists: " + fragment1.mTargetIndex); 
            } 
          } 
        } 
        this.mAdded.clear();
        if (fragmentManagerState.mAdded != null) {
          i = 0;
          while (i < fragmentManagerState.mAdded.length) {
            null = (Fragment)this.mActive.get(fragmentManagerState.mAdded[i]);
            if (null == null)
              throwException(new IllegalStateException("No instantiated fragment for index #" + fragmentManagerState.mAdded[i])); 
            null.mAdded = true;
            if (DEBUG)
              Log.v("FragmentManager", "restoreAllState: added #" + i + ": " + null); 
            if (this.mAdded.contains(null))
              throw new IllegalStateException("Already added!"); 
            synchronized (this.mAdded) {
              this.mAdded.add(null);
              i++;
            } 
          } 
        } 
        if (fragmentManagerState.mBackStack != null) {
          this.mBackStack = new ArrayList<BackStackRecord>(fragmentManagerState.mBackStack.length);
          for (i = 0; i < fragmentManagerState.mBackStack.length; i++) {
            BackStackRecord backStackRecord = fragmentManagerState.mBackStack[i].instantiate(this);
            if (DEBUG) {
              Log.v("FragmentManager", "restoreAllState: back stack #" + i + " (index " + backStackRecord.mIndex + "): " + backStackRecord);
              PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
              backStackRecord.dump("  ", printWriter, false);
              printWriter.close();
            } 
            this.mBackStack.add(backStackRecord);
            if (backStackRecord.mIndex >= 0)
              setBackStackIndex(backStackRecord.mIndex, backStackRecord); 
          } 
        } else {
          this.mBackStack = null;
        } 
        if (fragmentManagerState.mPrimaryNavActiveIndex >= 0)
          this.mPrimaryNav = (Fragment)this.mActive.get(fragmentManagerState.mPrimaryNavActiveIndex); 
        this.mNextFragmentIndex = fragmentManagerState.mNextFragmentIndex;
        return;
      } 
    } 
  }
  
  FragmentManagerNonConfig retainNonConfig() {
    setRetaining(this.mSavedNonConfig);
    return this.mSavedNonConfig;
  }
  
  Parcelable saveAllState() {
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    this.mSavedNonConfig = null;
    if (this.mActive != null && this.mActive.size() > 0) {
      int k = this.mActive.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[k];
      int j = 0;
      int i;
      for (i = 0; i < k; i++) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          if (fragment.mIndex < 0)
            throwException(new IllegalStateException("Failure saving state: active " + fragment + " has cleared index: " + fragment.mIndex)); 
          byte b = 1;
          FragmentState fragmentState = new FragmentState(fragment);
          arrayOfFragmentState[i] = fragmentState;
          if (fragment.mState > 0 && fragmentState.mSavedFragmentState == null) {
            fragmentState.mSavedFragmentState = saveFragmentBasicState(fragment);
            if (fragment.mTarget != null) {
              if (fragment.mTarget.mIndex < 0)
                throwException(new IllegalStateException("Failure saving state: " + fragment + " has target not in fragment manager: " + fragment.mTarget)); 
              if (fragmentState.mSavedFragmentState == null)
                fragmentState.mSavedFragmentState = new Bundle(); 
              putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment.mTarget);
              if (fragment.mTargetRequestCode != 0)
                fragmentState.mSavedFragmentState.putInt("android:target_req_state", fragment.mTargetRequestCode); 
            } 
          } else {
            fragmentState.mSavedFragmentState = fragment.mSavedFragmentState;
          } 
          j = b;
          if (DEBUG) {
            Log.v("FragmentManager", "Saved state of " + fragment + ": " + fragmentState.mSavedFragmentState);
            j = b;
          } 
        } 
      } 
      if (!j) {
        if (DEBUG) {
          Log.v("FragmentManager", "saveAllState: no fragments!");
          return null;
        } 
        return null;
      } 
      int[] arrayOfInt = null;
      BackStackState[] arrayOfBackStackState2 = null;
      j = this.mAdded.size();
      if (j > 0) {
        int[] arrayOfInt1 = new int[j];
        i = 0;
        while (true) {
          arrayOfInt = arrayOfInt1;
          if (i < j) {
            arrayOfInt1[i] = ((Fragment)this.mAdded.get(i)).mIndex;
            if (arrayOfInt1[i] < 0)
              throwException(new IllegalStateException("Failure saving state: active " + this.mAdded.get(i) + " has cleared index: " + arrayOfInt1[i])); 
            if (DEBUG)
              Log.v("FragmentManager", "saveAllState: adding fragment #" + i + ": " + this.mAdded.get(i)); 
            i++;
            continue;
          } 
          break;
        } 
      } 
      BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
      if (this.mBackStack != null) {
        j = this.mBackStack.size();
        arrayOfBackStackState1 = arrayOfBackStackState2;
        if (j > 0) {
          arrayOfBackStackState2 = new BackStackState[j];
          i = 0;
          while (true) {
            arrayOfBackStackState1 = arrayOfBackStackState2;
            if (i < j) {
              arrayOfBackStackState2[i] = new BackStackState(this.mBackStack.get(i));
              if (DEBUG)
                Log.v("FragmentManager", "saveAllState: adding back stack #" + i + ": " + this.mBackStack.get(i)); 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      FragmentManagerState fragmentManagerState = new FragmentManagerState();
      fragmentManagerState.mActive = arrayOfFragmentState;
      fragmentManagerState.mAdded = arrayOfInt;
      fragmentManagerState.mBackStack = arrayOfBackStackState1;
      if (this.mPrimaryNav != null)
        fragmentManagerState.mPrimaryNavActiveIndex = this.mPrimaryNav.mIndex; 
      fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
      saveNonConfig();
      return fragmentManagerState;
    } 
    return null;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    Bundle bundle2 = null;
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    if (!this.mStateBundle.isEmpty()) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    Fragment.SavedState savedState2 = null;
    if (paramFragment.mIndex < 0)
      throwException(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager")); 
    Fragment.SavedState savedState1 = savedState2;
    if (paramFragment.mState > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView != null) {
      if (this.mStateArray == null) {
        this.mStateArray = new SparseArray();
      } else {
        this.mStateArray.clear();
      } 
      paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
      if (this.mStateArray.size() > 0) {
        paramFragment.mSavedViewState = this.mStateArray;
        this.mStateArray = null;
        return;
      } 
    } 
  }
  
  void saveNonConfig() {
    ArrayList<Fragment> arrayList5 = null;
    ArrayList<Fragment> arrayList1 = null;
    ArrayList<Fragment> arrayList4 = null;
    ArrayList<Fragment> arrayList3 = null;
    ArrayList<Fragment> arrayList6 = null;
    ArrayList<Fragment> arrayList2 = null;
    if (this.mActive != null) {
      int i = 0;
      while (true) {
        arrayList4 = arrayList3;
        arrayList5 = arrayList1;
        arrayList6 = arrayList2;
        if (i < this.mActive.size()) {
          Fragment fragment = (Fragment)this.mActive.valueAt(i);
          arrayList5 = arrayList3;
          arrayList6 = arrayList1;
          ArrayList<Fragment> arrayList = arrayList2;
          if (fragment != null) {
            FragmentManagerNonConfig fragmentManagerNonConfig;
            arrayList4 = arrayList1;
            if (fragment.mRetainInstance) {
              byte b;
              arrayList5 = arrayList1;
              if (arrayList1 == null)
                arrayList5 = new ArrayList(); 
              arrayList5.add(fragment);
              if (fragment.mTarget != null) {
                b = fragment.mTarget.mIndex;
              } else {
                b = -1;
              } 
              fragment.mTargetIndex = b;
              arrayList4 = arrayList5;
              if (DEBUG) {
                Log.v("FragmentManager", "retainNonConfig: keeping retained " + fragment);
                arrayList4 = arrayList5;
              } 
            } 
            if (fragment.mChildFragmentManager != null) {
              fragment.mChildFragmentManager.saveNonConfig();
              fragmentManagerNonConfig = fragment.mChildFragmentManager.mSavedNonConfig;
            } else {
              fragmentManagerNonConfig = fragment.mChildNonConfig;
            } 
            arrayList1 = arrayList3;
            if (arrayList3 == null) {
              arrayList1 = arrayList3;
              if (fragmentManagerNonConfig != null) {
                arrayList3 = new ArrayList<Fragment>(this.mActive.size());
                int j = 0;
                while (true) {
                  arrayList1 = arrayList3;
                  if (j < i) {
                    arrayList3.add(null);
                    j++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            if (arrayList1 != null)
              arrayList1.add(fragmentManagerNonConfig); 
            arrayList3 = arrayList2;
            if (arrayList2 == null) {
              arrayList3 = arrayList2;
              if (fragment.mViewModelStore != null) {
                arrayList2 = new ArrayList<Fragment>(this.mActive.size());
                int j = 0;
                while (true) {
                  arrayList3 = arrayList2;
                  if (j < i) {
                    arrayList2.add(null);
                    j++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            arrayList5 = arrayList1;
            arrayList6 = arrayList4;
            arrayList = arrayList3;
            if (arrayList3 != null) {
              arrayList3.add(fragment.mViewModelStore);
              arrayList = arrayList3;
              arrayList6 = arrayList4;
              arrayList5 = arrayList1;
            } 
          } 
          i++;
          arrayList3 = arrayList5;
          arrayList1 = arrayList6;
          arrayList2 = arrayList;
          continue;
        } 
        break;
      } 
    } 
    if (arrayList5 == null && arrayList4 == null && arrayList6 == null) {
      this.mSavedNonConfig = null;
      return;
    } 
    this.mSavedNonConfig = new FragmentManagerNonConfig(arrayList5, (List)arrayList4, (List)arrayList6);
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 93
    //   38: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 80
    //   44: ldc 'FragmentManager'
    //   46: new java/lang/StringBuilder
    //   49: dup
    //   50: invokespecial <init> : ()V
    //   53: ldc_w 'Setting back stack index '
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: iload_1
    //   60: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   63: ldc_w ' to '
    //   66: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   69: aload_2
    //   70: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   73: invokevirtual toString : ()Ljava/lang/String;
    //   76: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   79: pop
    //   80: aload_0
    //   81: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   84: iload_1
    //   85: aload_2
    //   86: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   89: pop
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: iload_3
    //   94: iload_1
    //   95: if_icmpge -> 176
    //   98: aload_0
    //   99: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   102: aconst_null
    //   103: invokevirtual add : (Ljava/lang/Object;)Z
    //   106: pop
    //   107: aload_0
    //   108: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   111: ifnonnull -> 125
    //   114: aload_0
    //   115: new java/util/ArrayList
    //   118: dup
    //   119: invokespecial <init> : ()V
    //   122: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   125: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   128: ifeq -> 157
    //   131: ldc 'FragmentManager'
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: ldc_w 'Adding available back stack index '
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: iload_3
    //   147: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   150: invokevirtual toString : ()Ljava/lang/String;
    //   153: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   156: pop
    //   157: aload_0
    //   158: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   161: iload_3
    //   162: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   165: invokevirtual add : (Ljava/lang/Object;)Z
    //   168: pop
    //   169: iload_3
    //   170: iconst_1
    //   171: iadd
    //   172: istore_3
    //   173: goto -> 93
    //   176: getstatic android/support/v4/app/FragmentManagerImpl.DEBUG : Z
    //   179: ifeq -> 218
    //   182: ldc 'FragmentManager'
    //   184: new java/lang/StringBuilder
    //   187: dup
    //   188: invokespecial <init> : ()V
    //   191: ldc_w 'Adding back stack index '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: iload_1
    //   198: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   201: ldc_w ' with '
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: aload_2
    //   208: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   211: invokevirtual toString : ()Ljava/lang/String;
    //   214: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   217: pop
    //   218: aload_0
    //   219: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   222: aload_2
    //   223: invokevirtual add : (Ljava/lang/Object;)Z
    //   226: pop
    //   227: goto -> 90
    //   230: astore_2
    //   231: aload_0
    //   232: monitorexit
    //   233: aload_2
    //   234: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	230	finally
    //   20	29	230	finally
    //   38	80	230	finally
    //   80	90	230	finally
    //   90	92	230	finally
    //   98	125	230	finally
    //   125	157	230	finally
    //   157	169	230	finally
    //   176	218	230	finally
    //   218	227	230	finally
    //   231	233	230	finally
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment != null && (this.mActive.get(paramFragment.mIndex) != paramFragment || (paramFragment.mHost != null && paramFragment.getFragmentManager() != this)))
      throw new IllegalArgumentException("Fragment " + paramFragment + " is not an active fragment of FragmentManager " + this); 
    this.mPrimaryNav = paramFragment;
  }
  
  public void showFragment(Fragment paramFragment) {
    boolean bool = false;
    if (DEBUG)
      Log.v("FragmentManager", "show: " + paramFragment); 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      if (!paramFragment.mHiddenChanged)
        bool = true; 
      paramFragment.mHiddenChanged = bool;
    } 
  }
  
  void startPendingDeferredFragments() {
    if (this.mActive != null) {
      int i = 0;
      while (true) {
        if (i < this.mActive.size()) {
          Fragment fragment = (Fragment)this.mActive.valueAt(i);
          if (fragment != null)
            performPendingDeferredStart(fragment); 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    if (this.mParent != null) {
      DebugUtils.buildShortClassTag(this.mParent, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    } 
    DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore #4
    //   6: aload #4
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore_2
    //   11: aload_0
    //   12: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   15: invokevirtual size : ()I
    //   18: istore_3
    //   19: iload_2
    //   20: iload_3
    //   21: if_icmpge -> 51
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_2
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast android/support/v4/util/Pair
    //   35: getfield first : Ljava/lang/Object;
    //   38: aload_1
    //   39: if_acmpne -> 61
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_2
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: aload #4
    //   53: monitorexit
    //   54: return
    //   55: astore_1
    //   56: aload #4
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    //   61: iload_2
    //   62: iconst_1
    //   63: iadd
    //   64: istore_2
    //   65: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   11	19	55	finally
    //   24	51	55	finally
    //   51	54	55	finally
    //   56	59	55	finally
  }
  
  private static class AnimateOnHWLayerIfNeededListener extends AnimationListenerWrapper {
    View mView;
    
    AnimateOnHWLayerIfNeededListener(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.mView = param1View;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (ViewCompat.isAttachedToWindow(this.mView) || Build.VERSION.SDK_INT >= 24) {
        this.mView.post(new Runnable() {
              public void run() {
                FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.this.mView.setLayerType(0, null);
              }
            });
      } else {
        this.mView.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$0.mView.setLayerType(0, null);
    }
  }
  
  private static class AnimationListenerWrapper implements Animation.AnimationListener {
    private final Animation.AnimationListener mWrapped;
    
    private AnimationListenerWrapper(Animation.AnimationListener param1AnimationListener) {
      this.mWrapped = param1AnimationListener;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationEnd(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationRepeat(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationRepeat(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationStart(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationStart(param1Animation); 
    }
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    private AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator == null)
        throw new IllegalStateException("Animator cannot be null"); 
    }
    
    private AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation == null)
        throw new IllegalStateException("Animation cannot be null"); 
    }
  }
  
  private static class AnimatorOnHWLayerIfNeededListener extends AnimatorListenerAdapter {
    View mView;
    
    AnimatorOnHWLayerIfNeededListener(View param1View) {
      this.mView = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.mView.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.mView.setLayerType(2, null);
    }
  }
  
  private static class EndViewTransitionAnimator extends AnimationSet implements Runnable {
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimator(@NonNull Animation param1Animation, @NonNull ViewGroup param1ViewGroup, @NonNull View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      if (this.mEnded)
        return !this.mTransitionEnded; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
        return true;
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      if (this.mEnded)
        return !this.mTransitionEnded; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
        return true;
      } 
      return true;
    }
    
    public void run() {
      this.mParent.endViewTransition(this.mChild);
      this.mTransitionEnded = true;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      if (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null) {
        FragmentManager fragmentManager = FragmentManagerImpl.this.mPrimaryNav.peekChildFragmentManager();
        if (fragmentManager != null && fragmentManager.popBackStackImmediate())
          return false; 
      } 
      return FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    private final boolean mIsBack;
    
    private int mNumPostponed;
    
    private final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      boolean bool1;
      boolean bool2 = false;
      if (this.mNumPostponed > 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int j = fragmentManagerImpl.mAdded.size();
      for (int i = 0; i < j; i++) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(i);
        fragment.setOnStartEnterTransitionListener(null);
        if (bool1 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
      } 
      fragmentManagerImpl = this.mRecord.mManager;
      BackStackRecord backStackRecord = this.mRecord;
      boolean bool = this.mIsBack;
      if (!bool1)
        bool2 = true; 
      fragmentManagerImpl.completeExecute(backStackRecord, bool, bool2, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      this.mNumPostponed--;
      if (this.mNumPostponed != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\support\v4\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */