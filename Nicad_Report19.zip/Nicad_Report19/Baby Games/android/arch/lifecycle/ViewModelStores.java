package android.arch.lifecycle;

import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

public class ViewModelStores {
  @MainThread
  @NonNull
  public static ViewModelStore of(@NonNull Fragment paramFragment) {
    return (paramFragment instanceof ViewModelStoreOwner) ? ((ViewModelStoreOwner)paramFragment).getViewModelStore() : HolderFragment.holderFragmentFor(paramFragment).getViewModelStore();
  }
  
  @MainThread
  @NonNull
  public static ViewModelStore of(@NonNull FragmentActivity paramFragmentActivity) {
    return (paramFragmentActivity instanceof ViewModelStoreOwner) ? ((ViewModelStoreOwner)paramFragmentActivity).getViewModelStore() : HolderFragment.holderFragmentFor(paramFragmentActivity).getViewModelStore();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\arch\lifecycle\ViewModelStores.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */